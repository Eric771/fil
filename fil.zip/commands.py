# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
from random import randint
from archimed import Archimed
from Naked.toolshed.shell import execute_js
from api.kaboom import Kaboom
from api import LineClient
from api.settings import LineHeaders
from api.services.ttypes import TalkException
import time
import random
import sys
import json
import codecs
import threading
import subprocess
import glob
import re
import string
import os
import requests
import ast
import pytz
import traceback
import importlib

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Days %02d Hours %02d Minutes' % (days, hours, mins)
class beta():
    uid = None
    namen = None
    client = None
    sett = None
    awit = None
    mode = None
    app = False
#    creator = ["ub1a7b63155625df4c3703b667dae4eab","ud342c6bd7b56c3978031bb73b0032505","u7f3da73894de33534ab333234de190ab"]
    creator = ["uc3f7917c21cd24d63d2d4bd3bb0463ae","u8858887270faa2486a7f8001e2660cb2","uc130a4ebca07a938e84c911583c21e8a","u58f11b3a243fd37c6c30e05b2266fe61","u0e26aa062b3c9900ac0dcf2507cad70e"]
    tempbots = []
    addcmd = ""
    addcommand = False
    addbackup = False
    addbkp = False
    addajs = False
    delbackup = False
    duedate = None

    def __init__(self,uid=None,namen=None,client=None,sett=None,awit=None,mode=None,app=None,cover=None):
        self.uid = uid
        self.namen = namen
        self.client = client
        self.set = sett
        self.awit = awit
        self.mode = mode
        self.app = app
        self.cover = cover
        self.bye = 0
        self.pro = 0
        self.spam = False
        self.spamname = ''
        self.sasaran = []
        self.tempban = []
        self.invban = []
        self.point = time.time()
        self.commands = self.set["commands"]
        self.settings = self.set["settings"]
        self.status = self.set["status"]
        self.duedate = parser.parse(self.status["duedate"])
        self.jepitan = []
    #    self.client.send_message("u24d2ce778ab32cf95090a15c3d9a5a0a","juh")
    def async_notified_kickout_from_group(self,op):
                            kicker = op.param2
                            kicked = op.param3
                            kroom = op.param1
                            if self.uid == kicked:
                                if self.pangkat(kroom,kicker) > 8:
                                   self.addbl(kicker)
                            elif kroom in self.settings["protect"]:
                                if self.settings["protect"][kroom] == 0:
                                    if self.pangkat(kroom,kicker) > 8:
                                        if self.pangkat(kroom,kicked) < 9:
                                            self.addbl(kicker)

                                elif self.settings['war'] and kicked in self.status['squad']:
                                    if self.pangkat(kroom,kicker) > 8:
                                        self.addbl(kicker)
                                        try:
                                            self.client.kick_out_from_group(kroom,[kicker])
                                            self.client.invite_into_group(kroom,self.status['squad'])
                                        except TalkException as talk_error:
                                            if talk_error.code == 10:
                                                self.logError("Bot not in room {}".format(kroom))
                                            elif talk_error.code == 35:
                                                self.logError("limit")
                                                g = self.client.get_compact_group(kroom)
                                                links = g.preventedJoinByTicket
                                                if links == True:
                                                    g.preventedJoinByTicket = False
                                                    self.client.update_group(g)
                                                link = self.client.reissue_group_ticket(kroom)
                                                self.client.send_message(kicked,"%s %s"%(kroom,link))

                                elif self.pangkat(kroom,kicked) < 8 and self.pangkat(kroom,kicker) > 8:
                                        self.addbl(kicker)
                                        try:
                                            self.client.kick_out_from_group(kroom,[kicker])
                                            self.client.invite_into_group(kroom,[kicked])
                                        except TalkException as talk_error:
                                            if talk_error.code == 10:
                                                self.logError("Bot not in room {}".format(kroom))
                                            elif talk_error.code == 35:
                                              self.logError("limit")
                                              if op.param3 in self.status['squad'] or op.param3 in self.status['bot']:
                                                g = self.client.get_compact_group(kroom)
                                                links = g.preventedJoinByTicket
                                                if links == True:
                                                    g.preventedJoinByTicket = False
                                                    self.client.update_group(g)
                                                link = self.client.reissue_group_ticket(kroom)
                                                self.client.send_message(kicked,"%s %s"%(kroom,link))
                                elif self.settings["protect"][kroom] == 2 and self.pangkat(kroom,kicker) > 8:
                                    self.addbl(kicker)
                                    time.sleep(0.001)
                                    self.purge(op.param1)
                                    #self.client.kick_out_from_group(kroom, [kicker])

    def async_notified_invite_into_group(self,op):
                            grup = op.param1
                            inviter = op.param2
                            invites = op.param3.split('\x1e')
                            if self.uid in op.param3:
                                if self.pangkat(grup,inviter) < 7:
                                    self.client.accept_group_invitation(grup)
                                    if inviter in self.status['anti']:
                                       self.settings['protect'][grup] = 2
                                       self.backupData()

                                    #elif self.settings['nuke']:
                                        #x = self.client.get_compact_group(grup)
                                        #nama = [contact.mid for contact in x.members]
                                        #targets = []
                                        #for a in nama:
                                            #if self.pangkat(grup,a) > 8 and a != self.uid:
                                                #targets.append(a)
                                        #if targets == []:
                                            #pass
                                        #else:
                                            #cms = 'simple.js gid={} token={} app={}'.format(grup,self.client.authToken,self.app)
                                            #for y in targets:
                                                #cms += ' uid={}'.format(y)
                                            #success = execute_js(cms)
                                            #if success:
                                                #self.client.send_message(inviter,'Execute success')
                                            #else:
                                                #self.client.send_message(inviter,'error')

                                    elif self.settings['nuke']:
                                        x = self.client.get_compact_group(grup)
                                        nama = [contact.mid for contact in x.members]
                                        ban = set(members).intersection(self.setting["blacklist"])
                                        cms = 'simple.js gid={} token={} app={}'.format(grup,self.client.authToken,self.app)
                                        for y in ban:
                                        	cms += " uid={}".format(y)
                                        success = execute_js(cms)
                                        if success:
                                        	self.client.send_message(inviter,'kick allbanned user')
                                        else:
                                        	self.client.send_message(inviter,'Im limit')

                            elif grup in self.settings["protect"]:
                                if self.settings["protect"][grup] > 0:
                                    if not set(self.status['blacklist']).isdisjoint(invites):
                                        band = set(self.status['blacklist']).intersection(invites)
                                        for c in band:
                                            self.client.cancel_group_invitation(grup,[c])
                                        if self.pangkat(grup,inviter) > 8:
                                            self.addbl(inviter)
                                            self.client.kick_out_from_group(grup,[inviter])

                                    elif inviter in self.status['blacklist']:
                                        self.client.kick_out_from_group(grup,[inviter])
                                        self.invban = invites
                                        for target in invites:
                                            self.client.cancel_group_invitation(grup,[target])
                                    elif grup in self.settings['cancel']:
                                        if self.pangkat(grup,inviter) > 8:
                                            self.invban = invites
                                            for target in invites:
                                                self.client.cancel_group_invitation(grup,[target])
                                            if self.settings['cancel'][grup] == 2:
                                                self.addbl(inviter)
                                                self.client.kick_out_from_group(grup,[inviter])

    def async_notified_accept_group_invitation(self,op):
                            if op.param1 in self.settings["protect"]:
                              if self.settings["protect"][op.param1] > 0:
                                if op.param2 in self.status['blacklist']:
                                    if self.settings['lock']:
                                      if self.tempban != []: 
                                        group = self.client.get_group(op.param1)
                                        members = [o.mid for o in group.members]
                                        matched_list = []
                                        matched_list.append(op.param2)
                                        for tag in self.tempban:
                                            matched_list+=filter(lambda str: str == tag, members)
                                        if group.preventedJoinByTicket == False:
                                            group.preventedJoinByTicket = True
                                            self.client.update_group(group)
                                        for c in matched_list:
                                            self.client.kick_out_from_group(op.param1,[c])
                                      else:self.client.kick_out_from_group(op.param1,[op.param2])
                                    else:self.client.kick_out_from_group(op.param1,[op.param2])
                                elif op.param2 in self.invban and self.pangkat(op.param1,op.param2) > 8:
                                       self.client.kick_out_from_group(op.param1,[op.param2])
                                       self.invban.remove(op.param2)
                                elif op.param1 in self.settings['blj'] and self.pangkat(op.param1,op.param2) > 8:
                                       self.client.kick_out_from_group(op.param1,[op.param2])
    def async_notified_cancel_invitation_group(self,op):
                              if op.param3 != self.uid and self.pangkat(op.param1,op.param2) > 8:
                                if op.param1 in self.settings['protect']:
                                    if self.pangkat(op.param1,op.param3) < 8 and self.settings['protect'][op.param1] > 0:
                                        self.addbl(op.param2)
                                        self.client.invite_into_group(op.param1,[op.param3])
                                        self.client.kick_out_from_group(op.param1, [op.param2])
                                    elif self.settings['protect'][op.param1] == 2:
                                        self.addbl(op.param2)
                                        self.client.kick_out_from_group(op.param1, [op.param2])
    def async_notified_update_group(self,op):
                                    if op.param3 == '1':
                                        if op.param1 in self.settings['namelock'] and self.pangkat(op.param1,op.param2) > 8:
                                            cek = self.client.get_compact_group(op.param1)
                                            cek.name = self.settings['namelock'][op.param1]
                                            self.client.update_group(cek)
                                            if op.param1 in self.settings['protect'] and self.settings['protect'][op.param1] > 1:
                                                self.client.kick_out_from_group(op.param1,[op.param2])
                                                self.addbl(op.param2)
                                    else:
                                        if op.param1 in self.settings['linkprotect'] and self.pangkat(op.param1,op.param2) > 8:
                                                cek = self.client.get_compact_group(op.param1)
                                                if cek.preventedJoinByTicket == False:
                                                    cek.preventedJoinByTicket = True
                                                    self.client.update_group(cek)
                                                    if self.settings['linkprotect'][op.param1] == 2:
                                                        self.addbl(op.param2)
                                                        self.client.kick_out_from_group(op.param1,[op.param2])
                                        elif op.param1 in self.settings["protect"]:
                                          if self.settings["protect"][op.param1] > 0:
                                            if op.param2 in self.status['blacklist']:
                                                cek = self.client.get_compact_group(op.param1)
                                                if cek.preventedJoinByTicket == False:
                                                    cek.preventedJoinByTicket = True
                                                    self.client.update_group(cek)
                                                    if op.param1 in self.settings['protect'] and self.settings['protect'][op.param1] > 0:
                                                        self.client.kick_out_from_group(op.param1,[op.param2])

                                            elif self.settings['lock']:
                                                if op.param2 not in self.tempban and self.pangkat(op.param1,op.param2) > 8:
                                                    self.tempban.append(op.param2)
    def async_notified_read_message(self,op):
                            if op.param2 in self.status['blacklist'] and op.param1 in self.settings['protect']:
                                if self.settings['protect'][op.param1] > 0:
                                   self.client.kick_out_from_group(op.param1,[op.param2])
    def async_notified_leave_group(self,op):
                            if op.param2 in self.status['anti'] and op.param1 in self.settings['protect']:
                                if self.settings['protect'][op.param1] > 0:
                                    self.client.invite_into_group(op.param1, [op.param2])
    def async_accept_group_invitation(self,op):
                            if op.param1 not in self.settings['protect']:
                                self.settings['protect'][op.param1] = 0
                            if self.settings["purge"]:
                                self.purge(op.param1)
                                group = self.client.get_group(op.param1)
                                members = [o.mid for o in group.members]
                                if not set(members).isdisjoint(self.status["blacklist"]):
                                    band = set(members).intersection(self.status["blacklist"])
                                    for ban in band:
                                        self.client.kick_out_from_group(op.param1,[ban])
                            if op.param1 not in self.settings["protect"]:
                                self.settings["protect"][to] = 1
    def purge(self,to):
        try:
            x = self.client.get_compact_group(to)
            members = [contact.mid for contact in x.members]
            ban = set(members).intersection(self.status["blacklist"])
            cms = "simple.js gid={} token={}".format(to, self.client.authToken)
            for y in ban:
                cms += " uid={}".format(y)
            success = execute_js(cms)
        except:
            e = traceback.format_exc()
            if "code=35" in e:
                print("limited...")
                
    def async_auto(self):
        if self.invban != [] or self.tempban != []:
            if time.time() - self.point >= 60:
                self.invban = []
                self.tempban = []
                self.point = time.time()
    def pangkat(self, room, userr):
        u = self.creator
        if userr in u:
            return 0
        u = self.status['owner']
        if userr in u:
            return 1
        u = self.status['admin']
        if userr in u:
            return 2
        u = self.status['staff']
        if userr in u:
            return 3
        u = self.status['squad']
        if userr in u:
            return 4
        u = self.status['bot']
        if userr in u:
            return 5
        u = self.status['anti']
        if userr in u:
            return 6
        if room in self.status['gaccess']:
            self.access = self.status['gaccess'][room]
            u = self.access['gowner']
            if userr in u:
                return 7
            u = self.access['gadmin']
            if userr in u:
                return 8
        return 1000

    def addbl(self, user):
        if user in self.status['blacklist'] or not self.settings['allowban']:
            pass
        else:
            self.status['blacklist'].append(user)
            self.backupData()
        return 1
    def mention(self,msg,targets):
        if msg.mentionees:
            for mention in msg.mentionees:
                targets.append(mention)
    def backupData(self):
        with open('thb/'+self.namen+'.json', 'w') as fp:
            json.dump(self.set, fp, sort_keys=True, indent=4)
    def sendtag(self, to, text="",eto="", mids=[], isUnicode=False):
        arrData = ""
        arr = []
        mention = "@Jeck Maniz "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            unicode = ""
            if isUnicode:
                for mid in mids:
                    unicode += str(texts[mids.index(mid)].encode('unicode-escape'))
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx) if unicode == textx else len(textx) + unicode.count('U0')
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            else:
                for mid in mids:
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx)
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            textx += str(texts[len(mids)])
        else:
            raise Exception("Invalid mention position")
        self.client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    def mycmd(self,text,wait,msg):
        cmd = ''
        pesan = text
        if msg.from_id in wait['cname']:
            rname =  wait['cname'][msg.from_id]
        else:rname = wait['rname']
        if msg.from_id in wait['dname']:
            sname =  wait['dname'][msg.from_id]
        else:sname = wait['sname']
        if pesan.lower().startswith(rname):
                if ' & ' in text:
                    cmd = pesan.split(' & ')
                else:
                    cmd = [pesan]
        elif pesan.lower().startswith(sname):
                if ' & ' in text:
                    cmd = pesan.split(' & ')
                else:
                    cmd = [pesan]
        elif pesan.lower().startswith("oup"):
                if ' & ' in text:
                    cmd = pesan.split(' & ')
                else:
                    cmd = [pesan]
        return cmd

    def abort(self,to,silent):
        self.status["repeat"] = False
        if self.status["abl"]:
            self.status["abl"] = False
        if self.status["invite"]:
            self.status["invite"] = False
        if self.status["abot"]:
            self.status["abot"] = False
        if self.status["aadmin"]:
            self.status["aadmin"] = False
        if self.status["expel"]:
            self.status["expel"] = False
        if self.status["astaff"]:
            self.status["astaff"] = False
        if self.status['picture']:
            self.status["picture"] = False
        if self.status['cvp']:
            self.status["cvp"] = False
        self.addcommand = False
        self.addbackup = False
        self.addbkp = False
        self.addajs = False
        self.delbackup = False
        self.spam = False
        self.spamname = ''
        self.sasaran = []
        self.backupData()
        if not silent:self.client.send_message(to,"Command done")

    def listdata(self,to,status,text='',ps='',data=[]):
        k = len(data)//20
        for aa in range(k+1):
            if aa == 0:dd = '    {} '.format(text,ps);no=aa
            else:dd = '    {} '.format(text,ps);no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n{}. @!'.format(no)
                else:msgas+='\n{}. @!'.format(no)
            if data == []:pass
            else:self.sendtag(to, msgas,'  {} '.format(ps), data[aa*20: (aa+1)*20])
    def logError(self,text):
      try:
        print('ERROR')
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        timeHours = datetime.strftime(timeNow,"(%H:%M)")
        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        inihari = datetime.now(tz=tz)
        hr = inihari.strftime('%A')
        bln = inihari.strftime('%m')
        for i in range(len(day)):
            if hr == day[i]: hasil = hari[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
        with open("log/e{}".format(self.namen),"a") as error:
            error.write("\n[ {} ] {}".format(str(time), text))
      except Exception as e:
        traceback.print_exc()
    def ranking(self, room, userr):
        u = self.creator
        if userr in u:
            return 0
        u = self.status['owner']
        if userr in u:
            return 1
        u = self.status['admin']
        if userr in u:
            return 2
        u = self.status['staff']
        if userr in u:
            return 3
        if room in self.status['gaccess']:
            self.access = self.status['gaccess'][room]
            u = self.access['gowner']
            if userr in u:
                return 4
            u = self.access['gadmin']
            if userr in u:
                return 5
        return 1000
    def listcon(self,to,msg,num,status,data=[]):
        if data == []:
            self.client.send_message(to, "  Empty List ")
        else:
                    nama = data
                    no = 0
                    targets = []
                    selection = Archimed(num,range(1,len(nama)+1))
                    for i in selection.parse():
                        targets.append(nama[i-1])
                    for target in targets:
                          try:
                              self.client.send_contact(msg.to_id,target)
                          except Exception as e:traceback.print_exc()

    def mentionmention(self,to,status, text, dataMid=[], pl='', ps='',pg='',pt=[]):
        arr = []
        list_text=ps
        i=0
        no=pl
        if pg == 'MENTIONALLME':
            for l in dataMid:
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text+text
        if pg == 'DELFL':
            for l in dataMid:
                try:
                    self.client.delcon(l)
                    a = 'Del Friend'
                except:
                    a = 'Not Friend User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=text+list_text
        if pg == 'ADDFL':
            lss = self.client.refreshContacts()
            for l in dataMid:
                if not l in self.uid and l not in lss:
                   self.client.add_contact_by_mid(l)
                no+=1
                list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDWL':
            for l in dataMid:
              if not l in self.uid:
                if l in status["bot"]:
                    a = 'whitelist'
                else:
                    if l not in status["blacklist"]:
                        a = 'whitelist'
                        status["bot"].append(l)
                        self.client.add_contact_by_mid(l)
                    else:
                        a = 'BL User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDST':
            for l in dataMid:
              if not l in self.uid:
                if l in status["staff"]:
                    a = 'Already Staff'
                else:
                    a = 'Add staff'
                    status["staff"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELST':
            for l in dataMid:
                if l not in status["staff"]:
                    a = 'Not staff'
                else:
                    a = 'DEL staff'
                    status["staff"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDGO':
            for l in dataMid:
              if not l in self.uid:
                if to in status['gaccess']:
                        if l in status['gaccess'][to]["gowner"]:
                            a = 'Already Gowner'
                        else:
                            a = 'Add Gowner'
                            status['gaccess'][to]["gowner"].append(l)
                            self.client.add_contact_by_mid(l)
                else:
                    status['gaccess'][to] = {'gowner':[],'gadmin':[]}
                    a = 'Add Gowner'
                    status['gaccess'][to]["gowner"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELGO':
            for l in dataMid:
                if to in status['gaccess']:
                        if l in status['gaccess'][to]["gowner"]:
                            a = 'Del Gowner'
                            status['gaccess'][to]["gowner"].remove(l)
                else:
                    pass
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDGA':
            for l in dataMid:
              if not l in self.uid:
                if to in status['gaccess']:
                        if l in status['gaccess'][to]["gadmin"]:
                            a = 'Already Gowner'
                        else:
                            a = 'Add Gowner'
                            status['gaccess'][to]["gadmin"].append(l)
                            self.client.add_contact_by_mid(l)
                else:
                    status['gaccess'][to] = {'gowner':[],'gadmin':[]}
                    a = 'Add GAdmin'
                    status['gaccess'][to]["gadmin"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELGA':
            for l in dataMid:
                if to in status['gaccess']:
                        if l in status['gaccess'][to]["gadmin"]:
                            a = 'Del Gowner'
                            status['gaccess'][to]["gadmin"].remove(l)
                else:
                    pass
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text

        if pg == 'ADDBO':
            for l in dataMid:
              if not l in self.uid:
                if l in status["squad"]:
                    a = 'Already Warlist'
                else:
                    a = 'Warlist added'
                    status["squad"].append(l)
                    status["bot"].append(l)
                    time.sleep(9)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBO':
            for l in dataMid:
                if l not in status["squad"]:
                    a = 'Not Warlist'
                else:
                    a = 'DEL Warlist'
                    status["squad"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBK':
            for l in dataMid:
              if not l in self.uid:
                if l in status["anti"]:
                    a = 'Sampun Bolo'
                else:
                    a = 'Add squad'
                    status["anti"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDC':
            for l in dataMid:
              if not l in self.uid:
                a = 'Add Con'
                self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBK':
            for l in dataMid:
                if l not in status["anti"]:
                    a = 'Not Bolo'
                else:
                    a = 'del squad'
                    status["anti"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBKP':
            for l in dataMid:
              if not l in self.uid:
                if l in status["backup"]["all"]:
                    a = 'Wes Bolo'
                else:
                    a = 'Add squad'
                    status["backup"]["all"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBKP':
            for l in dataMid:
                if l not in status["backup"]["all"]:
                    a = 'Not Bolo'
                else:
                    a = 'del squad'
                    status["backup"]["all"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDADM':
            for l in dataMid:
              if not l in self.uid:
                if l in status["admin"]:
                    a = 'Done Admin'
                else:
                    a = 'Add Admin'
                    status["admin"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELADM':
            for l in dataMid:
                if l not in status["admin"]:
                    a = 'Not Admin'
                else:
                    a = 'DEL Admin'
                    status["admin"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDOWN':

            for l in dataMid:
                if l in status["owner"]:
                    a = 'Done Owner'
                else:
                    a = 'Add Owner'
                    status["owner"].append(l)
                    self.client.add_contact_by_mid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELOWN':
            for l in dataMid:
                if l not in status["owner"]:
                    a = 'Not Owner'
                else:
                    a = 'DEL Owner'
                    status["owner"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBL':
            for l in dataMid:
                if l in status["bot"]:
                    a = 'Bot access'
                else:
                    if l not in status["blacklist"]:
                        a = 'Add BL'
                        status["blacklist"].append(l)
                    else:
                        a = 'BL User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=text+list_text
        if pg == 'DELWL':
            for l in dataMid:
                try:
                    status["bot"].remove(l)
                    a = 'Del Bot'
                except:
                    a = 'Dereng whitelist'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=text+list_text
        if pg == 'DELBL':
            for l in dataMid:
                try:
                    status["blacklist"].remove(l)
                    a = 'Del BL'
                except:
                    a = 'Not BL User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'. @[oup-'+str(i)+'] '
                i=i+1
            text=text+list_text
        i=0
        for l in dataMid:
          if l not in self.uid:
            mid=l
            name='@[oup-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int( ln_text.index(name) )
                line_e=(int(line_s)+int( len(name) ))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    def cleartemp(self,to):
                        gid = self.client.get_joined_group_mids()
                        al = []
                        bl = []
                        cf = []
                        dl = []
                        el = []
                        for a in self.settings["cancel"]:
                            if a not in gid:
                                al.append(a)
                        for b in self.settings["protect"]:
                            if b not in gid:
                                bl.append(b)
                        for c in self.settings["linkprotect"]:
                            if c not in gid:
                                cf.append(c)
                        for d in self.settings["namelock"]:
                            if d not in gid:
                                dl.append(d)
                        for e in self.settings["blj"]:
                            if e not in gid:
                                el.append(e)
                        for z in al:
                            del self.settings["cancel"][z]
                        for z in bl:
                            del self.settings["protect"][z]
                        for z in cf:
                            del self.settings["linkprotect"][z]
                        for z in dl:
                            del self.settings["namelock"][z]
                        for z in el:
                            del self.settings["blj"][z]

    def async_receive_message(self,op):
      try:
        msg = op.message
        to = msg.to_id
        saya = msg.from_id
        silent = self.settings["mute"]
        text = msg.text
        if msg.from_id in self.settings['cname']:
            rname =  self.settings['cname'][msg.from_id].lower() + " "
        else:rname = self.settings['rname'].lower() + " "
        if msg.from_id in self.settings['dname']:
            sname =  self.settings['dname'][msg.from_id].lower() + " "
        else:sname = self.settings['sname'].lower() + " "
        if msg.content_type == 0:
                if None == msg.text:
                   return
                if msg.to_type == 0:
                    to = msg.from_id
                    if self.pangkat(to,saya) < 6:

                        if not rname in text.lower():
                            cond = text.split(" ")
                            if len(cond) == 2:
                               gid = msg.text.split()[0]
                               link = msg.text.split()[1]
                               self.client.accept_group_invitation_by_ticket(gid,link)

                if msg.text in self.status['wordban']:
                  if self.pangkat(to,saya) > 6:
                    self.client.kick_out_from_group(to,[saya])
                txt = msg.text.lower()
                txt = " ".join(txt.split())
                if txt.startswith(rname) or txt.startswith(sname) or txt.startswith('thb '):
                   cmds = self.mycmd(txt,self.settings,msg)
                else:cmds=[]
                if self.pangkat(to,saya) == 0:
                  if txt.startswith(self.settings["rname"]+"helpadd "):
                                sep = txt.split(" ")
                                query = txt.replace(sep[0] + " "+sep[1] + " ","")
                                isinya = query.split(" $ ")
                                with open('helpi.json','r') as ini:
                                     uh = json.load(ini)
                                if not "protect" in uh:
                                   uh = {"protect":[],"creator":[],"owner":[],"admin":[],"staff":[]}
                                   with open('helpi.json','w') as fp:
                                      json.dump(uh, fp, sort_keys=True, indent=4)
                                if sep[1] == "prot":
                                   lis = uh["protect"]
                                if sep[1] == "creator":
                                   lis = uh["creator"]
                                if sep[1] == "owner":
                                   lis = uh["owner"]
                                if sep[1] == "admin":
                                   lis = uh["admin"]
                                if sep[1] == "staff":
                                   lis = uh["staff"]
                                d = []
                                b = 0
                                mc = ""
                                for t in isinya:
                                   if t not in lis:
                                      lis.append(t)
                                      d.append(t)
                                with open('helpi.json','w') as fp:
                                      json.dump(uh, fp, sort_keys=True, indent=4)
                                for mi_d in d:
                                          b = b + 1
                                          end = '\n'
                                          mc += str(b) + " - " + mi_d + "\n"
                                with open('helpi.json','w') as fp:
                                      json.dump(uh, fp, sort_keys=True, indent=4)
                                self.client.sendMessage(to,"Success add help message:\n"+mc)
                  if txt.startswith(self.settings["rname"]+"helpdel "):
                                    sep = msg.text.split(" ")
                                    with open('helpi.json','r') as ini:
                                       uh = json.load(ini)
                                    if sep[1] == "prot":
                                       lis = uh["protect"]
                                    if sep[1] == "creator":
                                       lis = uh["creator"]
                                    if sep[1] == "owner":
                                       lis = uh["owner"]
                                    if sep[1] == "admin":
                                       lis = uh["admin"]
                                    if sep[1] == "staff":
                                       lis = uh["staff"]
                                    selection = Archimed(self.client.nyeplitin(msg.text,'s'),range(1,len(lis)+1))
                                    d = []
                                    for c in selection.parse():
                                        d.append(lis[int(c)-1])
                                    for a in d:
                                        lis.remove(a)
                                    mc = ""
                                    b = 0
                                    for mi_d in d:
                                          b = b + 1
                                          end = '\n'
                                          mc += str(b) + " - " + mi_d + "\n"
                                    with open('helpi.json','w') as fp:
                                      json.dump(uh, fp, sort_keys=True, indent=4)
                                    self.client.sendMessage(to,"Success remove help message:\n"+mc)
                  for a in cmds:
                    if a.startswith(rname):txt = a.replace(a[:len(rname)],'')
                    elif a.startswith(sname):txt = a.replace(a[:len(sname)],'')
                    elif a.startswith("cuy"):txt = a.replace(a[:len("cuy")]+' ','')
                    elif cmds.index(a) != 0 and rname not in a and sname not in a:txt = a
                    if txt.startswith("date "):
                        date = txt.split(' ')[1]
                        self.duedate = parser.parse(date)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Duedate set to %s."%self.duedate)
                    if txt == 'reboot':
                                        self.settings["reb"] = to
                                        self.backupData()
                                        if not self.settings["mute"]:self.client.send_message(to,"Restarting system...")
                                        python3 = sys.executable
                                        os.execl(python3, python3, *sys.argv)
                    if txt.startswith('setreboot '):
                       wk = txt.split()[1]
                       if wk.isdigit:
                          self.settings['kick'] = int(wk)
                          self.client.send_message(to, 'Rebooting sleep set to {}'.format(wk))
                    if txt == 'cek rsleep':
                        rb = self.settings['kick']
                        self.client.send_message(to, str(rb))
                    if txt == "addmonth":
                        self.duedate = self.duedate + relativedelta(months=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been extended with 1 month")
                    if txt == "decmonth":
                        self.duedate = self.duedate - relativedelta(months=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been deducted with 1 month.")
                    if txt == "addweek":
                        self.duedate = self.duedate + relativedelta(weeks=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been extended with 1 week.")
                    if txt == "decweek":
                        self.duedate = self.duedate - relativedelta(weeks=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been decrased 1 week.")
                    if txt == "addday":
                        self.duedate = self.duedate + relativedelta(days=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been extended with with 1 day.")
                    if txt == "decday":
                        self.duedate = self.duedate - relativedelta(days=1)
                        self.status["duedate"] = str(self.duedate)
                        self.backupData()
                        if not silent:self.client.send_message(to,"Time has been deducted with with 1 day.")
                    if txt == "logs":
                                a=subprocess.getoutput('cat log/e{}'.format(self.namen))
                                k = len(a)//10000
                                for aa in range(k+1):
                                    if not silent:self.client.send_message(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))
                                try:
                                   os.remove('log/e{}'.format(self.namen))
                                except:pass
                    if txt == "clearlogs":
                                try:
                                   os.remove('log/e{}'.format(self.namen))
                                   self.client.send_message(to,'Done.')
                                except:
                                   self.client.send_message(to,'Logs is empty.') 
                    if txt.startswith("addowner"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if target in self.status["staff"]:
                               self.status["staff"].remove(target)
                            if target in self.status["bot"]:
                               self.status["bot"].remove(target)
                            if target in self.status["admin"]:
                               self.status["admin"].remove(target)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Owner Add \n',pg='ADDOWN',pt=targets)
                      else:
                        self.status["aowner"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()

                    if txt.startswith("delowner"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Owner \n',pg='DELOWN',pt=targets)
                      else:
                        data = txt.replace("delowner","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['owner'])+1))
                        k = len(self.status['owner'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['owner'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del Owner \n',pg='DELOWN',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del Owner \n',pg='DELOWN',pt=d)
                      self.backupData()

                if self.pangkat(to,saya) < 2:
                  if txt == 'rgbots'.lower() or \
                                txt == rname.replace(" ","").lower() or \
                                txt == sname.replace(" ","").lower():
                                if not silent:self.sendtag(to,"Hey @! i'm here",rname, [saya])
                  
                  if msg.text.lower().startswith(rname + "sname ") or msg.text.lower().startswith(sname + "sname ") or txt.startswith("default sname: "):
                            sep = msg.text.lower().split(": ")
                            self.settings["sname"] = sep[1]
                            self.backupData()
                            if not silent:self.client.send_message(to,"Squad name changed to " +self.settings["sname"])

                  if msg.text.lower().startswith(rname+"r:"):
                        if not "r: " in msg.text.lower():
                            number = msg.text.lower().split("r:")[1]
                            number = number.split()[0]
                            num = int(number)
                            gid = self.client.get_joined_group_mids()
                            sumi = gid[num-1]
                            group = sumi
                            to = group
                            if not " & " in msg.text.lower():
                               z = msg.text.lower().replace(rname+"r:%s "%number,"").lstrip().rstrip()
                               cmds = [z]
                               if not silent:self.client.send_message(msg.to_id,"Command '%s' sent to group %s."%(z.replace(rname,""),self.client.get_group(group).name))
                            else:
                               z = msg.text.lower().replace(rname+"r:%s "%number,"").lstrip().rstrip()
                               cmds = z.split(" & ")
                               if not silent:self.client.send_message(msg.to_id,"Multi Command '%s' sent to group %s."%(z.replace(rname,""),self.client.get_group(group).name))
                  if msg.text.lower().startswith(sname+"r:"):
                        if not "r: " in msg.text.lower():
                            number = msg.text.lower().split("r:")[1]
                            number = number.split()[0]
                            num = int(number)
                            gid = self.client.get_joined_group_mids()
                            sumi = gid[num-1]
                            group = sumi
                            to = group
                            if not " & " in msg.text.lower():
                               z = msg.text.lower().replace(sname+"r:%s "%number,"").lstrip().rstrip()
                               cmds = [z]
                            else:
                               z = msg.text.lower().replace(sname+"r:%s "%number,"").lstrip().rstrip()
                               cmds = z.split(" & ")
                            if not silent:self.client.send_message(msg.to_id,"Command '%s' sent to group %s."%(msg.text[len(rname)-1:].lstrip(),self.client.get_group(group).name))
                  for a in cmds:
                    if a.startswith(rname):txt = a.replace(a[:len(rname)],'')
                    elif a.startswith(sname):txt = a.replace(a[:len(sname)],'')
                    elif a.startswith("rgbots"):txt = a.replace(a[:len("rgbots")]+' ','')
                    elif cmds.index(a) != 0 and rname not in a and sname not in a:txt = a
                    if txt == "shutdown":
                                        if not silent:self.client.send_message(msg.to_id,"Bot Nonactivate.")
                                        self.backupData()
                                        time.sleep(3)
                                        sys.exit()

                    if txt == '.nuke:on':
                        self.settings['nuke'] = True
                        self.backupData()
                        if not silent:self.client.send_message(msg.to_id,"Nuke mode enabled.")
                    if txt == '.nuke:off':
                        self.settings['nuke'] = False
                        self.backupData()
                        if not silent:self.client.send_message(msg.to_id,"Nuke mode disabled.")

                    if txt == 'clearprotect':
                        self.settings["cancel"] = {}
                        self.settings["linkprotect"] = {}
                        self.settings["protect"] = {}
                        self.settings["namelock"] = {}
                        self.settings["blj"] = {}
                        self.settings["purge"] = False
                        self.settings["lock"] = False
                        self.settings["war"] = False
                        self.backupData()
                        if not silent:self.client.send_message(msg.to_id, "All protection cleared.")
                    if txt == 'autopurge:on':
                        if self.settings["purge"] :
                            if not silent:self.client.send_message(msg.to_id, "Auto purge already enabled.")
                        else:
                            self.settings["purge"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Purge mode enabled.")
                    if txt == 'autopurge:off':
                        if self.settings["purge"] :
                            self.settings["purge"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Auto purge disabled.")
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Auto purge already disabled.")

                    if txt == 'urljoin:off':
                        if self.settings["atjoin"]:
                            self.settings["atjoin"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Url join disabled.")
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Urljoin already disabled.")
                    if txt == 'urljoin:on':
                        if self.settings["atjoin"]:
                            if not silent:self.client.send_message(msg.to_id, "Url join already enabled.")
                        else:
                            self.settings["atjoin"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Url join enabled.")
                    if txt == 'lock:on':
                        if self.settings["lock"] :
                            if not silent:self.client.send_message(msg.to_id, "Lock mode already enabled.")
                        else:
                            self.settings["lock"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Lock mode enabled.")
                    if txt == 'lock:off':
                        if self.settings["lock"] :
                            self.settings["lock"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Auto lock disabled.")
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Auto lock already disabled.")
                    if txt == 'war:off':
                      if self.mode == 1:
                        if not self.settings["war"] and not self.settings["cancelall"]:
                            if not silent:self.client.send_message(msg.to_id, "Already in normal mode.")
                        else:
                            self.settings["war"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "switched to normal mode.")
                    if txt == 'war:on':
                      if self.mode == 1:
                        if self.settings["war"]:
                            if not silent:self.client.send_message(msg.to_id, "Already in war mode.")
                        else:
                            self.settings["war"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "switched to war mode.")
                    if txt == 'mode1':
                      if self.mode == 1:
                        if self.settings["mode1"]:
                            if not silent:self.client.send_message(msg.to_id, "Mode 1 already enabled.")
                        else:
                            self.settings["mode1"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Mode 1 enabled.")
                    if txt == 'mode2':
                      if self.mode == 1:
                        if not self.settings["mode1"]:
                            if not silent:self.client.send_message(msg.to_id, "Mode 2 already enabled.")
                        else:
                            self.settings["mode1"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Mode 2 enabled.")
                    if txt == 'stay mode':
                      if self.mode == 0:
                        if self.settings["antimode"] :
                            if not silent:self.client.send_message(msg.to_id, "Standby mode already enabled.")
                        else:
                            self.settings["antimode"] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Protection switched to standby mode.")
                    if txt == 'normal mode':
                      if self.mode == 0:
                        if self.settings["antimode"] :
                            self.settings["antimode"] = False
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Protection switched to normal mode.")
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Protection already on normal mode.")

                    if txt == "bye:on":
                        self.bye = 1
                        if not silent:self.client.send_message(to,"Bye message enabled.")

                    if txt == "bye:off":
                        self.bye = 0
                        if not silent:self.client.send_message(to,"Bye message disabled.")
                    if txt == "duedate":
                        duedate = str(self.duedate).split()[0]
                        if not silent:self.client.send_message(to,duedate)

                    if txt == "timeleft":
                        timeleft = self.duedate - datetime.now()
                        days, seconds = timeleft.days, timeleft.seconds
                        hours = seconds / 3600
                        minutes = (seconds / 60) % 60
                        harto = "Time to due: %s Days, %s Hours, %s Minutes"%(days,round(hours),round(minutes))
                        if not silent:self.client.send_message(to,harto)

                    if txt == 'gettime':
                        t = time.time()*1000-int(op.createdTime)
                        backfire = 0.0
                        if(t < 30):
                            t = t/3
                            backfire = random.randint(1,5)
                        elif( t < 60):
                            t= t/6
                            backfire = random.randint(6,9)
                        else:
                            t = t/8
                            backfire = random.randint(0,9)
                        t = int(t)
                        t = t+(backfire/10.0)
                        if not silent:self.client.send_message(to,"%s"%t)
                    if txt == 'bot:room':
                       Data = self.status["bot"]
                       a = []
                       b = self.client.get_group(to)
                       lss = self.client.refreshContacts()
                       for i in b.members:
                        if i.mid not in Data and i.mid not in self.uid and self.pangkat(to,i.mid) > 6:
                            Data.append(i.mid)
                            a.append(i.mid)
                            if i.mid not in lss:
                               self.client.add_contact_by_mid(i.mid)
                            time.sleep(9)
                       if a == []:
                          if not silent:self.client.send_message(to,"Nothing to added.")
                       else:self.listdata(to,self.status,'Add whitelist','bot',a)
                       self.backupData()
                    if txt == "status":
                        try:self.client.invite_into_group(to, ["u957b70fea5594dc505ced3fd44d23d19"]);has = "Ready"
                        except:has = "I'm Limit"
                        if not silent:self.client.send_message(to, "{}".format(has))

                    if txt == 'global:room':
                       Data = self.status["bot"]
                       a = []
                       b = self.client.get_group(to)
                       for i in b.members:
                        if i.mid not in Data and i.mid not in self.uid and self.pangkat(to,i.mid) > 4:
                            Data.append(i.mid)
                            a.append(i.mid)
                       if a == []:
                          if not silent:self.client.send_message(to,"Nothing to added.")
                       else:self.listdata(to,self.status,'Add whitelist','bot',a)
                       self.backupData()

                    if txt == "invitebots":
                        if self.status["squad"] != []:
                            try:
                               self.client.invite_into_group(to, self.status["squad"])
                            except:
                               if not silent:self.client.send_message(to,"Limit.")
                        else:
                            if not silent:self.client.send_message(to,"Squad list is empty.")
                    if txt == "bot:qr":
                        g = self.client.get_compact_group(to)
                        links = g.preventedJoinByTicket
                        if links == True:
                            g.preventedJoinByTicket = False
                            self.client.update_group(g)
                        link = self.client.reissue_group_ticket(to)
                        for ki in self.status["squad"]:
                            self.client.send_message(ki,"%s %s"%(to,link))
                        time.sleep(0.1)
                        g.preventedJoinByTicket = True
                        self.client.update_group(g)
                    if txt.startswith("set flag: "):
                            sep = msg.text.split(": ")
                            stickername = msg.text.replace(sep[0] + ": ","")
                            self.settings["squad"] = stickername
                            self.backupData()
                            if not silent:self.client.send_message(to,"Squad flag name changed to " + self.settings["squad"])

                    if txt.startswith("uprname "):
                        string = txt.split(" ")[1]
                        self.settings["rname"] = string
                        self.backupData()
                        if not silent:self.client.send_message(to,"Responsename changed to " +self.settings["rname"])

                    if txt == "cname":
                        profile_B = self.client.profile
                        if msg.from_id in self.settings['cname']:
                            rn = self.settings['cname'][msg.from_id]
                        else:rn = self.settings["rname"]
                        profile_B.displayName = rn
                        self.client.update_profile_attribute(2, profile_B.displayName)
                        if not silent:self.client.send_message(to,"Display Name changed to " + self.settings["rname"])
                    if txt == "crname":
                        profile_B = self.client.profile
                        xn = str(profile_B.displayName)
                        if msg.from_id in self.settings['cname']:
                            rn = self.settings['cname'][msg.from_id]
                        else:rn = self.settings["rname"]
                        rn = xn.lower()
                        self.backupData()
                        if not silent:self.client.send_message(to,"Responsename changed to " +rn)
                    if txt.startswith("addcmd "):
                        if not self.addcommand:
                            command = txt.replace("addcmd ","")
                            self.addcmd = command.lstrip().rstrip()
                            self.addcommand = True
                            self.backupData()
                            if not silent:self.client.send_message(to,"Command %s added, send the contact."%command)
                        else:
                            if not silent:self.client.send_message(to,"Command  %s Already exist."%self.addcmd)
                    if txt.startswith('delcmd '):
                        cmd = txt.replace("delcmd ","").lstrip().rstrip()
                        if cmd in self.commands["invite"].keys():
                            del self.commands["invite"][cmd]
                            self.backupData()
                            if not silent:self.client.send_message(to,"Command %s deleted."%cmd)
                        else:
                            if not silent:self.client.send_message(to,"Command %s not exist."%cmd)

                    if txt.startswith("addbkp ") and self.mode == 0:
                        if msg.mentionees:
                           for key1 in msg.mentionees:
                                self.addcmd = key1
                                self.addbackup = True
                                try:
                                    self.client.add_contact_by_mid(key1)
                                except:
                                    traceback.print_exc()
                                if key1 not in self.tempbots:
                                   self.tempbots.append(key1)
                                self.backupData()
                                if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("delbkp") and self.mode == 0:
                        if msg.mentionees:
                            for key1 in msg.mentionees:
                                if key1 in self.status["backup"]:
                                   del self.status["backup"][key1]
                                   if not silent:self.client.send_message(to,"Success expeled from backup user")
                                else:self.client.send_message(to,"User not protected.")
                        else:
                            self.delbackup = True
                            if not silent:self.client.send_message(to,"Send contact.")
                        self.backupData()

                    if txt == 'done':
                        if self.addcommand:
                            self.commands["invite"][self.addcmd] = self.tempbots
                            if not silent:self.client.send_message(to,"Command %s successfully added."%self.addcmd)
                            self.addcmd = ""
                            self.tempbots = []
                            self.addcommand = False
                            self.backupData()
                        elif self.addbackup:
                            self.status["backup"][self.addcmd] = self.tempbots
                            if not silent:self.client.send_message(to,"Backup %s successfully added."%self.client.get_contact(self.addcmd).displayName)
                            self.addcmd = ""
                            self.tempbots = []
                            self.addbackup = False
                            self.backupData()
                        elif self.addbkp:
                            if not silent:self.client.send_message(to,"All Backup successfully added.")
                            self.addbkp = False
                            self.backupData()
                        
                    if txt.startswith("inv "):
                        txtk = txt.replace("inv ","")
                        jmlh = str(txtk)
                        if jmlh in self.commands["invite"]:
                          try:
                            self.client.invite_into_group(to, self.commands["invite"][jmlh])
                          except Exception as e:print(e)

                    if txt == "groups":
                        gid = self.client.get_joined_group_mids()
                        print(len(gid))
                        b = 0
                        h = ""
                        for a in gid:
                            b = b + 1
                            end = '\n'
                            h += str(b) + " - " + self.client.get_group(a).name + "\n"
                        if not silent:self.client.send_message(to,"List groups:" + "\n" + h + "Total [%s] groups" %str(len(gid)))
                    if txt == "gpending" or txt.startswith('gpending '):
                       gid = self.client.get_invited_group_mids()
                       if txt == 'gpending':
                        print(len(gid))
                        b = 0
                        h = ""
                        for a in gid:
                            b = b + 1
                            end = '\n'
                            h += str(b) + " - " + self.client.get_group(a).name + "\n"
                        if not silent:self.client.send_message(to,"List invitatation:" + "\n" + h + "Total [%s] groups" %str(len(gid)))
                       else:
                        txtk = int(txt.replace("gpending ",""))
                        p = self.client.get_group(gid[txtk-1])
                        print(gid[txtk-1])
                        b = 0
                        h = ""
                        gh = [i.mid for i in p.members]
                        for a in gh:
                            b = b + 1
                            end = '\n'
                            h += str(b) + " - " + self.client.get_contact(a).displayName + "\n"
                        if not silent:self.client.send_message(to,"List Members:" + "\n" + h + "Total [%s] groups" %str(len(gh)))

                    if txt == "cleartemp":
                        self.cleartemp(to)
                        self.client.send_message(to,"Tempfile Cleared")
                        self.backupData()

                    if txt.startswith("addadmin"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if target in self.status["staff"]:
                               self.status["staff"].remove(target)
                            if target in self.status["bot"]:
                               self.status["bot"].remove(target)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Admin Add \n',pg='ADDADM',pt=targets)
                      else:
                        self.status["aadmin"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()

                    if txt == "admin:repeat":
                        self.status["aadmin"] = True
                        self.status["repeat"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt == "bot:repeat":
                        self.status["abot"] = True
                        self.status["repeat"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("deladmin"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Admin \n',pg='DELADM',pt=targets)
                      else:
                        data = txt.replace("deladmin","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['admin'])+1))
                        k = len(self.status['admin'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['admin'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del Admin \n',pg='DELADM',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del Admin \n',pg='DELADM',pt=d)
                      self.backupData()

                    if txt.startswith("addbot"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if target in self.status["staff"]:
                                self.status["staff"].remove(target)
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Bot Add ',pg='ADDWL',pt=targets)
                      else:
                        self.status["abot"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()

                    if txt.startswith("addsquad"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if target in self.status["staff"]:
                                self.status["staff"].remove(target)
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Squad Add ',pg='ADDBO',pt=targets)
                        self.backupData()
                    if txt.startswith("addcon"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Contact Add ',pg='ADDFL',pt=targets)
                    if txt.startswith("delcon"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Friend ',pg='DELFL',pt=targets)
                      else:
                        split = txt.replace("delcon ","")   
                        nama = self.client.refreshContacts()
                        selection = Archimed(split,range(1,len(nama)+1))
                        k = len(nama)//100
                        d = []
                        for c in selection.parse():
                            d.append(nama[int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    del friends \n',pg='DELFL',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    del friends \n',pg='DELFL',pt=d)
                    if txt.startswith("friends ") or txt == "friends":
                                if txt.startswith('friends '):
                                     a = self.client.refreshContacts()
                                     data = txt.replace("friends","")
                                     text = data.split(' ')
                                     num = str(text[1])
                                     self.listcon(to,msg,num,self.status,a)
                                else:
                                     a = self.client.refreshContacts()
                                     k = len(a)//20
                                     for aa in range(k+1):
                                       if aa == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=a[:20],pl=0,ps='    Friends ',pg='MENTIONALLME',pt=a)
                                       else:self.mentionmention(to=to,status=self.status,text='',dataMid=a[aa*20 : (aa+1)*20],pl=aa*20,ps='    Friends ',pg='MENTIONALLME',pt=a)
                    if txt.startswith("delsquad"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    del squad \n',pg='DELBO',pt=targets)
                      else:
                        data = txt.replace("delsquad","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['squad'])+1))
                        k = len(self.status['squad'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['squad'][int(c)-1])
                            self.status["bot"].append(c)
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    del squad \n',pg='DELBO',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    del squad \n',pg='DELBO',pt=d)
                      self.backupData()
                    if txt.startswith("addajs") and self.mode == 1:
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Backup Add \n',pg='ADDBK',pt=targets)
                      else:self.addajs = True;self.client.send_message(msg.to_id, "Send contact.")
                      self.backupData()
                    if txt.startswith("delajs") and self.mode == 1:
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del ajs \n',pg='DELBK',pt=targets)
                      else:
                        data = txt.replace("delajs","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['anti'])+1))
                        k = len(self.status['anti'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['anti'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del ajs \n',pg='DELBK',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del ajs \n',pg='DELBK',pt=d)
                      self.backupData()

                    if txt.startswith("addbackup") and self.mode == 0:
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Backup Add \n',pg='ADDBKP',pt=targets)
                      else:self.addbkp = True;self.client.send_message(msg.to_id, "Send contact.")
                      self.backupData()
                    if txt.startswith("delbackup") and self.mode == 0:
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Backup \n',pg='DELBKP',pt=targets)
                      else:
                        data = txt.replace("delbackup","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['backup']["all"])+1))
                        k = len(self.status['backup']["all"])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['backup']["all"][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del Backup \n',pg='DELBKP',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del Backup \n',pg='DELBKP',pt=d)
                      self.backupData()
                    if txt == 'mute':
                        if self.settings["mute"]:
                            self.client.send_message(msg.to_id, "Already silent.")
                        else:
                            self.settings["mute"] = True
                            self.backupData()
                            self.client.send_message(msg.to_id, "I will silent.")

                    if txt == 'unmute':
                        if self.settings["mute"]:
                            self.settings["mute"] = False
                            self.backupData()
                            self.client.send_message(msg.to_id, "Hi i'm back...")
                        else:
                            self.client.send_message(msg.to_id, "I'm stay here.")
                    if txt.startswith("delbot"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Bot \n',pg='DELWL',pt=targets)
                      else:
                        data = txt.replace("delbot","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['bot'])+1))
                        k = len(self.status['bot'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['bot'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del Bot \n',pg='DELWL',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del Bot \n',pg='DELWL',pt=d)
                      self.backupData()

                    if txt == 'addall bots':
                        a = self.client.refreshContacts()
                        for target in self.status["bot"]:
                            if target not in self.client.profile.mid and target not in a:
                                try:
                                    self.client.add_contact_by_mid(target)
                                    time.sleep(0.33)
                                except Exception as e:
                                    pass
                    if txt == '.addme':
                                a = self.client.refreshContacts()
                                if msg.from_id not in a:
                                    self.client.add_contact_by_mid(msg.from_id)
                                    self.client.add_contact_by_mid("uce4019b35cf513cf4892e38d8e20b602")
                                    if not silent:self.client.send_message(to, "Okay...")
                                else:
                                    if not silent:self.client.send_message(to, "Already in friendlist...")
                    if txt == 'clearbackup' and self.mode == 0:
                                    self.status["backup"]["all"] = []
                                    if not silent:self.client.send_message(to, "Back cleared.")
                                    self.backupData()
                    if txt == 'clearbots':
                                    self.status["bot"] = []
                                    self.backupData()
                                    if not silent:self.client.send_message(to, "Bot cleared.")
                    if txt == 'clearadmin':
                                    self.status["admin"] = []
                                    self.backupData()
                                    if not silent:self.client.send_message(to, "Admin cleared.")
                    if txt == 'clearstaff':
                                    self.status["staff"] = []
                                    self.backupData()
                                    if not silent:self.client.send_message(to, "Staff cleared.")
                    if txt == 'clearajs':
                                    self.status["anti"] = []
                                    self.backupData()
                                    if not silent:self.client.send_message(to, "Stanby bot cleared.")
                    if txt == 'cleargaccess':
                                    self.status["gaccess"] = {}
                                    self.backupData()
                                    if not silent:self.client.send_message(to, "All gaccess cleared.")
                    if txt.startswith("delgaccess "):
                          nump = txt.split()[2]
                          lik = []
                          if nump.isdigit:
                            for a in self.status['gaccess']:
                                lik.append(a)
                            hi = lik[int(nump)-1]
                            del self.status['gaccess'][hi]
                            self.backupData()
                            if not silent:self.client.send_message(to, "Gaccess on '{}' cleared.".format(self.client.get_group(hi).name))
                    #if txt.startswith('leave'):
                        #gid = self.client.get_joined_group_mids()
                        #selection = Archimed(txt.split(' ')[2],range(1,len(gid)+1))
                        #k = len(gid)//100
                        #for a in range(k+1):
                            # a == 0:eto='   Leave Group '
                            #else:eto='   Leave Group '
                            # = ''
                            #no = 0
                            #for i in selection.parse()[a*100 : (a+1)*100]:
                                #self.client.leave_group(gid[i - 1])
                                #no+=1
                                #if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.get_group(gid[i - 1]).name)
                                #else:text+= "\n{}. {}".format(i,self.client.get_group(gid[i - 1]).name)
                            #if not silent:self.client.send_message(to,eto+text)

                    if txt.startswith('talk'):
                      try:
                        txtk = msg.text.split("|")
                        ng = str(txtk[1])
                        foo = str(txtk[2])
                        gid = self.client.get_joined_group_mids()
                        for i in gid:
                            h = self.client.get_group(i).name
                            if h == ng:
                                self.client.send_message(i,foo)
                      except Exception as e:traceback.print_exc()

                    if txt.startswith('invme '):
                        cond = txt.replace("invme ","")
                        num = int(cond)
                        gid = self.client.get_joined_group_mids()
                        group = self.client.get_group(gid[num-1])
                        self.client.add_contact_by_mid(saya)
                        self.client.invite_into_group(gid[num-1],[saya])
                    if txt.startswith('bc '):
                        text = txt.replace("bc ","")
                        gid = self.client.get_joined_group_mids()
                        if text == "":
                            if not silent:self.client.send_message(to,"Message is Empty")
                        else:
                            for i in gid:
                                self.client.send_message(i, text)
                    if txt == "leave:all":
                        gid = self.client.get_joined_group_mids()
                        for g in gid:
                            if g in to:
                                pass
                            else:
                                self.client.leave_group(g)
                        if not silent:self.client.send_message(to, "successfully left from all groups.")
                    if txt == "reject:all":
                        gid = self.client.get_invited_group_mids()
                        for g in gid:
                            self.client.reject_group_invitation(g)
                        if not silent:self.client.send_message(to, "successfully reject all invitatation.")
                    if txt == "removechat":
                            self.client.removeAllMessages(to)
                            if not silent:self.client.send_message(to,"chat cleared")

                    if txt.startswith('leave '):
                        ng = msg.text.replace('leave ','')
                        gid = self.client.get_joined_group_mids()
                        for i in gid:
                            h = self.client.get_group(i).name
                            if h == ng:
                                self.client.leave_group(i)
                                if not silent:self.client.send_message(to,"success left from {}".format(ng))

                    if txt.startswith("ownercon"):
                      data = txt.replace("ownercon","")
                      text = data.split(' ')
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,self.status["owner"])

                    if txt.startswith("admincon"):
                      data = txt.replace("admincon","")
                      text = data.split(' ')
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,self.status["admin"])

                    if txt == "ownerlist":
                        if self.status["owner"] != []:
                           self.listdata(to,self.status,'Bot Owner','own',self.status['owner'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")
                    if txt == "adminlist":
                        if self.status["admin"] != []:
                           self.listdata(to,self.status,'Bot Admin','adm',self.status['admin'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")
                    if txt == "upimage":
                        self.status['picture'] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send the picture.")
                    if txt == "updatecover":
                        self.adc = True
                        if not silent:self.client.send_message(to,"Send the picture.")
                    if txt == "upvideo":
                        self.status['cvp'] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send the video.")
                    if txt.startswith("upname "):
                        string = msg.text.split("upname ")[1]
                        profile_B = self.client.profile
                        profile_B.displayName = string
                        self.client.update_profile_attribute(2, profile_B.displayName)
                        if not silent:self.client.send_message(to,"Display Name changed to " + string)
                    if txt.startswith('upstatus '):
                        status = msg.text.split("upstatus ")[1]
                        self.client.set_profile_status(status)
                        if not silent:self.client.send_message(to,"Status changed to " + status)

                if self.pangkat(to,saya) < 3:
                  if "kick" in txt:
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if self.pangkat(to,target) < 9:
                                pass
                            else:
                                try:
                                    self.addbl(target)
                                except:
                                    traceback.print_exc()
                  if '/ti/g/' in msg.text and self.settings["atjoin"] and not 'kick' in txt:
                                regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = regex.findall(text)
                                tickets = []
                                gids = self.client.get_joined_group_mids()
                                for link in links:
                                    if link not in tickets:
                                        tickets.append(link)
                                for ticket in tickets:
                                    try:
                                        group = self.client.get_group_by_ticket(ticket)
                                    except:
                                        continue
                                    if group.id in gids:
                                        continue
                                    self.client.accept_group_invitation_by_ticket(group.id, ticket)
                  if msg.text.startswith(rname+"nk "):
                                        nk0 = msg.text.replace(rname+"nk ","")
                                        nk1 = nk0.lstrip()
                                        nk2 = nk1.replace("@","")
                                        nk3 = nk2.rstrip()
                                        _name = nk3
                                        gs = self.client.get_group(to)
                                        targets = []
                                        for s in gs.members:
                                            if _name in s.displayName:
                                                targets.append(s.mid)
                                        if targets == []:
                                            self.client.send_message(msg.to_id,"Target not match.")
                                        else:
                                            cms = 'simple.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            success = execute_js(cms)
                                            if success:
                                                self.client.send_message(to,'Execute success')
                                            else:
                                                 self.client.send_message(to,'error')
                  for a in cmds:
                    if a.startswith(rname):txt = a.replace(a[:len(rname)],'')
                    elif a.startswith(sname):txt = a.replace(a[:len(sname)],'')
                    elif a.startswith("rgbots"):txt = a.replace(a[:len("rgbots")]+' ','')
                    elif cmds.index(a) != 0 and rname not in a and sname not in a:txt = a
                    if txt.startswith("response "):
                                   if msg.mentionees:
                                       lists = []
                                       for mention in msg.mentionees:
                                           if mention not in lists:
                                               lists.append(mention)
                                       reee = ""
                                       for ls in lists:
                                           ret_ = "{}".format(str(ls))
                                       sep = text.split(" ")
                                       s = text.replace(sep[0] + " ","")
                                       sam = s.split("|")
                                       number = sam[1]
                                       if len(number) > 0:
                                           if number.isdigit():
                                               number = int(number)
                                               no = 1
                                               if number > 20000:                                             
                                                   self.client.send_message(to,"Max 20000")
                                               else:
                                                   for i in range(0,number):
                                                       ris = {
                                                            'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+ls,
                                                            'MSG_SENDER_NAME':  '˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ {}'.format(str(no)),
                                                            }
                                                       self.client.sendMessage(to, 'Responsename ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ {}'.format(str(no)), contentMetadata=ris)
                                                       no += 1
                                                       time.sleep(0.05)
                                   else:
                                       sp = txt.split(" ")
                                       number = sp[1]
                                       if len(number) > 0:
                                           if number.isdigit():
                                               number = int(number)
                                               no = 0
                                               no = (no+1)
                                               if number > 20000:                                             
                                                   self.client.send_message(to,"Max 20000")
                                               else:
                                                   lis =[]
                                                   group = self.client.get_group(to)
                                                   nama = [contact.mid for contact in group.members]
                                                   for i in range(0,number):
                                                       ris = {
                                                            'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+random.choice(nama),
                                                            'MSG_SENDER_NAME':  '˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ {}'.format(str(no)),
                                                            }
                                                       self.client.sendMessage(to, 'Responsename ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ {}'.format(str(no)), contentMetadata=ris)
                                                       no=(no+1)
                                                       time.sleep(0.05)
                    if txt.startswith("rescon "):
                                if msg.mentionees:
                                    targets = []
                                    self.mention(msg,targets)
                                    for ls in targets:
                                        contentMetadata = {'mid': ls, "MSG_SENDER_ICON": "https://os.line.naver.jp/os/p/"+ls, "MSG_SENDER_NAME": self.client.get_contact(ls).displayName}
                                        self.client.sendMessage(to, '', contentMetadata, 13)
                                        time.sleep(0.1)
                                else:
                                    if msg.to_type == 2:
                                          jum = txt.split(" ")[1]
                                          group = self.client.get_group(to)
                                          nama = [contact.mid for contact in group.members]
                                          lis = []
                                          if jum.isdigit():
                                            no = int(jum)
                                            for a in range(no):
                                              lis.append(random.choice(nama))
                                            for c in lis:
                                                contentMetadata = {
                                                    'mid': c,
                                                    'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+c,
                                                    'MSG_SENDER_NAME':  self.client.get_contact(c).displayName,
                                                }
                                                self.client.sendMessage(to, '', contentMetadata, 13)
                                                time.sleep(0.1)

                    if txt.startswith("respon "):
                                    if msg.to_type == 2:
                                          jum = txt.split(" ")[1]
                                          group = self.client.get_group(to)
                                          nama = [contact.mid for contact in group.members]
                                          lis = []
                                          if jum.isdigit():
                                            no = int(jum)
                                            for a in range(no):
                                              lis.append(random.choice(nama))
                                            for c in lis:
                                                ris = {
                                                    'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+c,
                                                    'MSG_SENDER_NAME':  self.client.get_contact(c).displayName,
                                                }
                                                text = "Bot Ready"
                                                self.client.sendMessage(to, text, contentMetadata=ris)
                                                time.sleep(0.1)

                    if txt.startswith("nuker"):
                        data = txt.replace("nuker","")
                        text = data.split(' ')
                        com = str(text[1])
                        gs = self.client.get_group(to)
                        nama = [contact.mid for contact in gs.members]
                        no = 0
                        targets = []
                        selection = Archimed(com,range(1,len(nama)+1))
                        for i in selection.parse():
                            targets.append(nama[i-1])
                        mc = ""
                        b = 0
                        for mi_d in targets:
                            b = b + 1
                            end = '\n'
                            mc += str(b) + " - " +self.client.get_contact(mi_d).displayName + "\n"
                        for target in targets:
                              try:
                                            cms = 'simple.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            print(cms)
                                            success = execute_js(cms)
                                            if success:
                                                self.client.send_message(to,'Execute success')
                                            else:
                                                self.client.send_message(to,'error')
                              except Exception as e:print(e)
                        if not silent:self.client.send_message(msg.to_id,"Trying to kick user :\n"+"\n"+mc+"\nFrom Group"+ gs.name)

                    if txt == 'ginfo':
                        group = self.client.get_group(to)
                        zxc = "  Group members \nName: "+group.name+"\nMember:"
                        total = "\nGroup ID:\n"+to
                        no = 0
                        if len(group.members) > 0:
                            for a in group.members:
                                no += 1
                                zxc += "\n   " + str(no) + ". " + a.displayName
                            if not silent:self.client.send_message(msg.to_id,zxc + total)

                    if txt.startswith('say '):
                        txti = txt.split("say ")
                        foo = str(txti[1])
                        if not silent:self.client.send_message(to, foo)
                    if txt == "squadlist":
                        if self.status['squad']:
                            self.listdata(to,self.status,'squad','bol',self.status['squad'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")
                    if txt == '@bye' or txt == '@back':
                        if self.bye == 1:
                            if not silent:self.client.send_message(to, "Byebye!! {} ".format(self.client.get_group(to).name))
                        self.client.leave_group(to)

                    if txt == 'whitelist':
                        mc = ""
                        a = 0
                        for m_id in self.status["bot"]:
                            a = a + 1
                            end = '\n'
                            try:
                               mc += str(a) + " ❉⊱ " +self.client.get_contact(m_id).displayName + "\n"
                            except Exception as e:self.status["bot"].remove(m_id);print("del {}".format(m_id))
                        self.backupData()
                        if not silent:self.client.send_message(to," ⌬ "+self.settings["squad"]+" ⌬\n   Whitelist   \n\n"+mc)

                    if txt == "run" or txt == "runtime":
                       eltime = time.time() - self.awit
                       cin = "Uptime "+waktu(eltime)
                       if not silent:self.client.send_message(to,cin)

                    if txt == "uinvite":
                        self.status["invite"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("unsend "):
                        args = txt.replace("unsend ","").lstrip().rstrip()
                        mes = 0
                        try:
                            mes = int(args)
                        except:
                            mes = 1
                        M = self.client.getRecentMessages(to, 101)
                        MId = []
                        for ind,i in enumerate(M):
                            if ind == 0:
                                pass
                            else:
                                if i._from == self.client.profile.mid:
                                    MId.append(i.id)
                                    if len(MId) == mes:
                                        break
                        def unsMes(id):
                            self.client.unsend_message(id)
                        for i in MId:
                            thread1 = threading.Thread(target=unsMes, args=(i,))
                            thread1.start()
                            thread1.join()
                    if txt == "staffs" or txt == 'access':
                       rname = self.settings["rname"]
                       tst = "       ⊰❉⊱ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ⊰❉⊱  "+ "\n\n  ⊰❉⊱ Bot Access ⊰❉⊱"
                       num=0
                       num1=0
                       num2=0
                       num3=0
                       num4=0
                       num5=0
                       uh = self.status
                       mstr1 = self.creator
                       mstr2 = uh["owner"]
                       mstr3 = uh["admin"]
                       mstr4 = uh["staff"]
                       num=(num+1)
                       num1=(num1+1)
                       num2=(num2+1)
                       num3=(num3+1)
                       num4=(num4+1)
                       num5=(num5+1)
                       tst += "\n\n        ⊰❉⊱ Creator ⊰❉⊱  "
                       for c in mstr1:
                        try:
                           c = self.client.get_contact(c).displayName
                           if num1 < 10:
                            tst += "\n %i.   %s "%(num1,c)
                           else:
                            tst += "\n %i. %s "%(num1,c)
                           num1=(num1+1)
                        except Exception as e:mstr1.remove(c)
                       if mstr2 != []:
                        tst += "\n\n       ⊰❉⊱ Owner ⊰❉⊱ "
                        for c in mstr2:
                          try:
                           c = self.client.get_contact(c).displayName
                           if num < 10:
                            tst += "\n %i.   %s "%(num,c)
                           else:
                            tst += "\n %i. %s "%(num,c)
                           num=(num+1)
                          except:mstr2.remove(c)
                       if mstr3 != []:
                        tst += "\n\n       ⊰❉⊱ Admin ⊰❉⊱ "
                        for c in mstr3:
                          try:
                           c = self.client.get_contact(c).displayName
                           if num2 < 10:
                            tst += "\n %i.   %s "%(num2,c)
                           else:
                            tst += "\n %i. %s "%(num2,c)
                           num2=(num2+1)
                          except:mstr3.remove(c)
                       if mstr4 != []:
                        tst += "\n\n       ⊰❉⊱ Staff ⊰❉⊱ "
                        for c in mstr4:
                          try:
                           c = self.client.get_contact(c).displayName
                           if num3 < 10:
                            tst += "\n %i.   %s "%(num3,c)
                           else:
                            tst += "\n %i. %s "%(num3,c)
                           num3=(num3+1)
                          except:mstr4.remove(c)
                       if to in uh['gaccess']:
                        akses = uh['gaccess'][to]
                        if akses['gowner'] != []:
                         tst += "\n\n       ⊰❉⊱ GOwner ⊰❉⊱ "
                         for c in akses['gowner']:
                          try:
                           c = self.client.get_contact(c).displayName
                           if num4 < 10:
                            tst += "\n %i.   %s "%(num4,c)
                           else:
                            tst += "\n %i. %s "%(num4,c)
                           num4=(num4+1)
                          except:akses['gowner'].remove(c)
                        if akses['gadmin'] != []:
                         tst += "\n\n       ⊰❉⊱ GAdmin ⊰❉⊱ "
                         for c in akses['gadmin']:
                          try:
                           c = self.client.get_contact(c).displayName
                           if num5 < 10:
                            tst += "\n %i.   %s "%(num5,c)
                           else:
                            tst += "\n %i. %s "%(num5,c)
                           num5=(num5+1)
                          except:akses['gadmin'].remove(c)
                       tst += "\n\n ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ "
                       if not silent:self.client.send_message(to,tst)
                    if txt == "all gaccess":
                       rname = self.settings["rname"]
                       tst = "       ⊰❉⊱ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ⊰❉⊱  "+ "\n\n  👑 Group Access 👑"
                       deli = []
                       if self.status['gaccess'] != {}:
                        for hi in self.status['gaccess']:
                          if self.status['gaccess'][hi]['gowner'] == [] and self.status['gaccess'][hi]['gadmin'] == []:
                            deli.append(hi)
                          else:
                            num=0
                            num1=0
                            num=(num+1)
                            num1=(num1+1)
                            tst += "\n\n ❉⊱ {} \n".format(self.client.get_group(hi).name)
                            if self.status['gaccess'][hi]['gowner'] != []:
                                tst += "\n           Group Owner  "
                                for c in  self.status['gaccess'][hi]['gowner']:
                                 try:
                                    z = self.client.get_contact(c).displayName
                                    if num < 10:
                                     tst += "\n %i.   %s "%(num,z)
                                    else:
                                     tst += "\n %i. %s "%(num,z)
                                    num=(num+1)
                                 except:
                                    self.status['gaccess'][hi]['gowner'].remove(c)
                            if self.status['gaccess'][hi]['gadmin'] != []:
                                tst += "\n\n           Group Admin  "
                                for c in  self.status['gaccess'][hi]['gadmin']:
                                 try:
                                    z = self.client.get_contact(c).displayName
                                    if num1 < 10:
                                     tst += "\n %i.   %s "%(num1,z)
                                    else:
                                     tst += "\n %i. %s "%(num1,z)
                                    num1=(num1+1)
                                 except:self.status['gaccess'][hi]['gadmin'].remove(c)
                       tst += "\n\n ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ "
                       if not silent:self.client.send_message(to,tst)
                       for a in deli:
                            del self.status['gaccess'][a]
                       self.backupData()
                    if txt == "gaccess" or txt.startswith("gaccess "):
                        if txt == "gaccess":
                            rname = self.settings["rname"]
                            tst = "       ⊰❉⊱ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ⊰❉⊱  "+ "\n\n  👑 Group Access 👑\n"
                            deli = []
                            num=0
                            num=(num+1)
                            if self.status['gaccess'] != {}:
                             for hi in self.status['gaccess']:
                               if self.status['gaccess'][hi]['gowner'] == [] and self.status['gaccess'][hi]['gadmin'] == []:
                                 deli.append(hi)
                               else:
                                 tst += "\n{} ❉⊱  {} ".format(num,self.client.get_group(hi).name)
                               num = (num+1)

                            tst += "\n\n ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ "
                            if not silent:self.client.send_message(to,tst)
                            for a in deli:
                                 del self.status['gaccess'][a]
                            self.backupData()
                        else:
                          nump = txt.split()[1]
                          lik = []
                          if nump.isdigit:
                            for a in self.status['gaccess']:
                                lik.append(a)
                            hi = lik[int(nump)-1]
                            tst = "       ⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱  "+ "\n\n  👑 Group Access 👑"
                            num=0
                            num1=0
                            num=(num+1)
                            num1=(num1+1)
                            tst += "\n\n ❉⊱ {} ❉⊱".format(self.client.get_group(hi).name)
                            if self.status['gaccess'][hi]['gowner'] != []:
                                tst += "\n           Group Owner  "
                                for c in  self.status['gaccess'][hi]['gowner']:
                                 try:
                                    z = self.client.get_contact(c).displayName
                                    if num < 10:
                                     tst += "\n %i.   %s "%(num,z)
                                    else:
                                     tst += "\n %i. %s "%(num,z)
                                    num=(num+1)
                                 except:
                                    self.status['gaccess'][hi]['gowner'].remove(c)
                            if self.status['gaccess'][hi]['gadmin'] != []:
                                tst += "\n\n           Group Admin  "
                                for c in  self.status['gaccess'][hi]['gadmin']:
                                 try:
                                    z = self.client.get_contact(c).displayName
                                    if num1 < 10:
                                     tst += "\n %i.   %s "%(num1,z)
                                    else:
                                     tst += "\n %i. %s "%(num1,z)
                                    num1=(num1+1)
                                 except:self.status['gaccess'][hi]['gadmin'].remove(c)
                            tst += "\n\n ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ "
                            if not silent:self.client.send_message(to,tst)
                    if txt == 'prot status':
                                a = "     Block Invite "
                                b = "     Block URL "
                                c = "     Main Protect "
                                e = "     Block Join "
                                f = "     Name Lock "
                                g = "     Kick "
                                aa = 0
                                bb = 0
                                cc = 0
                                ee = 0
                                ff = 0
                                gg = 0
                                gid = self.settings["cancel"]
                                for group in gid:
                                  if self.settings["cancel"] == {}:
                                    a += "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    aa += 1
                                    a += "\n" + str(aa) + ". " + str(G.name)
                                gid = self.settings["linkprotect"]
                                for group in gid:
                                  if self.settings["linkprotect"] == {}:
                                     b += "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    bb += 1
                                    b += "\n" + str(bb) + ". " + str(G.name)
                                gid = self.settings["protect"]
                                for group in gid:
                                  if self.settings["protect"] == {}:
                                     c += "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    cc += 1
                                    c += "\n" + str(cc) + ". " + str(G.name)
                                gid = self.settings["blj"]
                                for group in gid:
                                  if self.settings["blj"] == {}:
                                     e += "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    ee += 1
                                    e += "\n" + str(ee) + ". " + str(G.name)
                                gid = self.settings["namelock"]
                                for group in gid:
                                  if self.settings["namelock"] == {}:
                                     f = "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    ff += 1
                                    f += "\n" + str(ff) + ". " + str(G.name)
                                gid = self.settings["kick"]
                                for group in gid:
                                  if self.settings["kick"] == {}:
                                     g = "Empty"
                                  else:
                                    G = self.client.get_group(group)
                                    gg += 1
                                    g += "\n" + str(gg) + ". " + str(G.name)
                                if not silent:self.client.send_message(to,"  ⌬ "+self.settings["squad"]+"  \n  ⌬Set Status\n\n"+a+"\n\n"+b+"\n\n"+c+"\n\n"+e+"\n\n"+f+"\n\n"+g+"\n\n    ˜”*°⊰❉ ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ❉⊱°*”˜ ")

                    if txt.startswith("staffcon"):
                      data = txt.replace("staffcon","")
                      text = data.split(' ')
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,self.status["staff"])

                    if txt.startswith("botcon"):
                      data = txt.replace("botcon","")
                      text = data.split(' ')
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,self.status["bot"])

                    if txt.startswith("bancon"):
                      data = txt.replace("bancon","")
                      text = data.split(' ')
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,self.status["blacklist"])

                    if txt.startswith("expel"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        eto = "Expelled"
                        for target in targets:
                          if self.pangkat(to,saya) < 1:
                            if target in self.status["owner"]:
                                self.status["owner"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from owner",eto,[target])
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from admin",eto,[target])
                            if target in self.status["bot"]:
                                self.status["bot"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from bot",eto,[target])
                            if target in self.status["squad"]:
                                self.status["squad"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from bolo",eto,[target])
                            if target in self.status["staff"]:
                                self.status["staff"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from staff",eto,[target])
                            if to in self.status['gaccess']:
                                if target in self.status['gaccess'][to]['gowner']:
                                   self.status['gaccess'][to]['gowner'].remove(target)
                                   if not silent:self.sendtag(to,"access user @! expeled from gowner",eto,[target])
                                if target in self.status['gaccess'][to]['gadmin']:
                                   self.status['gaccess'][to]['gadmin'].remove(target)
                                   if not silent:self.sendtag(to,"access user @! expeled from gadmin",eto,[target])
                          if self.pangkat(to,saya) == 1:
                            if target in self.creator:
                                if not silent:self.sendtag(to,"Who are you @! ?\nThat's my creator",eto,[saya])
                            if target in self.status["owner"]:
                                if not silent:self.sendtag(to,"Stop @! ?\nYour access is to low",eto,[saya])
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from admin",eto,[target])
                            if target in self.status["bot"]:
                                self.status["bot"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from bot",eto,[target])
                            if target in self.status["squad"]:
                                self.status["squad"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from bolo",eto,[target])
                            if target in self.status["staff"]:
                                self.status["staff"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from staff",eto,[target])
                          if self.pangkat(to,saya) == 2:
                            if target in self.creator:
                                if not silent:self.sendtag(to,"Who are you @! ?\nThat's my creator",eto,[saya])
                            if target in self.status["owner"]:
                                if not silent:self.sendtag(to,"Who are you @! ?\nThat's my owner",eto,[saya])
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                                if not silent:self.sendtag(to,"Stop @! ?\nYour access is to low",eto,[saya])
                            if target in self.status["bot"]:
                                self.status["bot"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from bot",eto,[target])
                            if target in self.status["staff"]:
                                self.status["staff"].remove(target)
                                if not silent:self.sendtag(to,"access user @! expeled from staff",eto,[target])
                      else:
                        self.status["expel"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()

                    if txt == "repeat expel":
                        self.status["expel"] = True
                        self.status["repeat"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("copyname"):
                        targets = []
                        if msg.mentionees:
                            self.mention(msg,targets)
                            for target in targets:
                                try:
                                    self.client.copyName(target)
                                    if not silent:self.client.send_message(to, "Succes copy Name")
                                except:
                                    if not silent:self.client.send_message(to,"Failled")
                    if txt.startswith("copystatus"):
                        targets = []
                        if msg.mentionees:
                            self.mention(msg,targets)
                            for target in targets:
                                try:
                                    self.client.copyStatus(target)
                                    if not silent:self.client.send_message(to, "Succes copy Status")
                                except:
                                    if not silent:self.client.send_message(to,"Failled")
                    if txt.startswith("copypic"):
                        targets = []
                        if msg.mentionees:
                            self.mention(msg,targets)
                            for target in targets:
                                try:
                                    A = self.client.get_contact(target)
                                    url = "http://dl.profile.line.naver.jp"+A.picturePath
                                    xpath = self.client.download_regular(url)
                                    self.client.updateProfilePicture(xpath)
                                    os.remove(xpath)
                                    if not silent:self.client.send_message(to, "Succes copy Picture")
                                except:
                                    if not silent:self.client.send_message(to,"Failled")

                    if txt.startswith("pancal"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if self.pangkat(to,target) < 4:
                                pass
                            else:
                                try:
                                    self.client.kick_out_from_group(to,[target])
                                except:
                                    if not silent:self.client.send_message(msg.to_id, "Limit cok")
                    if txt.startswith("kick"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if self.pangkat(to,target) < 4:
                                pass
                            else:
                                try:
                                    self.client.kick_out_from_group(to,[target])
                                except:
                                    if not silent:self.client.send_message(msg.to_id, "Limit cok")
                    if txt.startswith("skick"):
                            targets = []
                            if msg.mentionees:
                                self.mention(msg,targets)
                                try:
                                            cms = 'simple.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            print(cms)
                                            success = execute_js(cms)
                                            if success:
                                                self.client.send_message(to,'Execute success')
                                            else:
                                                self.client.send_message(to,'error')
                                except Exception as e:
                                    if not silent:self.client.send_message(msg.to_id, "{}".format(e))
                    if txt == 'kaboom':
                        Kaboom(self.client,self.client.get_group(to))

                    if txt == 'pendinglist':
                                        x = self.client.get_group(to)
                                        nama = [contact.mid for contact in x.invitee]
                                        h = ''
                                        for a in nama:
                                           h += '{}'.format(self.client.get_contact(a).displayName)
                                        print(h)
                    if txt.startswith('@cleanse'):
                                        x = self.client.get_group(to)
                                        if x.invitee == None:
                                            nami = []
                                        else:nami = [contact.mid for contact in x.invitee]
                                        targeti = []
                                        for a in nami:
                                            if self.pangkat(to,a) > 6:
                                                targeti.append(a)
                                        if targeti == []:
                                            cmo = []
                                        else:
                                            cmo = 'cancel.js gid={} token={}'.format(to,self.client.authToken)
                                            for y in targeti:
                                                cmo += ' uid={}'.format(y)
                                        nama = [contact.mid for contact in x.members]
                                        targets = []
                                        for a in nama:
                                            if self.pangkat(to,a) > 4 and a != self.uid:
                                                targets.append(a)
                                        if targets == []:
                                            cms = []
                                        else:
                                            cms = 'simple.js gid={} token={}'.format(to,self.client.authToken)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                        tasks = [asyncio.ensure_future(self.nuker(cms)),asyncio.ensure_future(self.nuker(cmo))]
                                        asyncio.gather(*tasks)
                    if txt == "cleanse":
                                        x = self.client.get_group(to)
                                        nama = [contact.mid for contact in x.members]
                                        targets = []
                                        for a in nama:
                                            if self.pangkat(to,a) > 4 and a != self.uid:
                                                targets.append(a)
                                        if targets == []:
                                            self.client.send_message(msg.to_id,"Target not found.")
                                        else:
                                            cms = 'simple.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            success = execute_js(cms)
                                            if success:
                                                self.client.send_message(to,'Execute success')
                                            else:
                                                self.client.send_message(to,'error')
                    if txt.startswith('@nuker'):
                                        x = self.client.get_group(to)
                                        if x.invitee == None:nama = []
                                        else:nama = [contact.mid for contact in x.invitee]
                                        targets = []
                                        for a in nama:
                                            if self.pangkat(to,a) > 4:
                                                targets.append(a)
                                        nami = [contact.mid for contact in x.members]
                                        targetk = []
                                        cms = 'dual.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                        for a in nami:
                                            if self.pangkat(to,a) > 4 and a != self.uid:
                                                targetk.append(a)
                                        for y in targets:
                                            cms += ' uid={}'.format(y)
                                        for y in targetk:
                                            cms += ' uik={}'.format(y)
                                        self.client.sendMessage(msg.to_id,'Please wait...')
                                        print(cms)
                                        success = execute_js(cms)
                                        if success:
                                                self.client.sendMessage(to,'Execute success')
                                        else:
                                                self.client.sendMessage(to,'error')
                    if txt == "purge":
                        if msg.to_type == 2:
                            group = self.client.get_group(to)
                            gMembMids = [contact.mid for contact in group.members]
                            matched_list = []
                            for tag in self.status["blacklist"]:
                                matched_list+=filter(lambda str: str == tag, gMembMids)
                            if matched_list == []:
                                pass
                            else:
                                            cms = 'simple.js gid={} token={} app={}'.format(to,self.client.authToken,self.app)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            print(cms)
                                            success = execute_js(cms)
                                            if success:
                                                self.client.send_message(to,'Execute success')
                                            else:
                                                self.client.send_message(to,'error')

                    if txt.startswith("addstaff"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        for target in targets:
                            if target in self.status["bot"]:
                                self.status["bot"].remove(target)
                            if target in self.status["admin"]:
                                self.status["admin"].remove(target)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Add staff \n',pg='ADDST',pt=targets)
                      else:
                        self.status["astaff"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()
                   
                    if txt == "staff:repeat":
                        self.status["astaff"] = True
                        self.status["repeat"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("delstaff"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del staff \n',pg='DELST',pt=targets)
                      else:
                        data = txt.replace("delstaff","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['staff'])+1))
                        k = len(self.status['staff'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['staff'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del staff \n',pg='DELST',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del staff \n',pg='DELST',pt=d)
                      self.backupData()

                    if txt.startswith("ban:on"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Blacklist \n',pg='ADDBL',pt=targets)
                      else:
                        self.status["abl"] = True
                        if not silent:self.client.send_message(to,"Send contact.")
                      self.backupData()

                    if txt == "ban:repeat":
                        self.status["abl"] = True
                        self.status["repeat"] = True
                        self.backupData()
                        if not silent:self.client.send_message(to,"Send contact.")

                    if txt.startswith("unban:on"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del staff \n',pg='DELST',pt=targets)
                      else:
                        data = txt.replace("unban:on","")
                        text = data.split(' ')
                        com = str(text[1])
                        selection = Archimed(com,range(1,len(self.status['blacklist'])+1))
                        k = len(self.status['blacklist'])//100
                        d = []
                        for c in selection.parse():
                            d.append(self.status['blacklist'][int(c)-1])
                        for a in range(k+1):
                            if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Unbanned \n',pg='DELBL',pt=d)
                            else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Unbanned \n',pg='DELBL',pt=d)
                      self.backupData()

                    if txt == 'stafflist':
                        if self.status['staff'] != []:
                           self.listdata(to,self.status,'Staff List','staff',self.status['staff'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")
                    if txt == 'ajslist' and self.mode == 1:
                        if self.status["anti"] != []:
                           self.listdata(to,self.status,'AJS List','own',self.status['anti'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")
                    if txt == 'botlist':
                        if self.status["bot"] != []:
                           self.listdata(to,self.status,'Bot List','own',self.status['bot'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")

                    if txt == 'backuplist' and self.mode == 0:
                        if self.status['backup']["all"] != []:
                           self.listdata(to,self.status,'Backup List','own',self.status['backup']["all"])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")

                    if txt == 'flist':
                        if self.status["squad"] == []:
                            if not silent:self.client.send_message(to,"Empty list")
                        else:
                            mc = ""
                            b = 0
                            for mi_d in self.status["squad"]:
                                b = b + 1
                                end = '\n'
                                try:
                                   mc += str(b) + " ❉⊱ " +self.client.get_contact(mi_d).displayName + "\n"
                                except Exception as e:self.status["squad"].remove(mi_d);print("del {}".format(mi_d))
                            self.backupData()
                            if not silent:self.client.send_message(to,"  Squad list:\n"+"\n"+mc)

                    if txt == 'banlist':
                        if self.status['blacklist'] != []:
                           self.listdata(to,self.status,'Blacklist','own',self.status['blacklist'])
                        else:
                            if not silent:self.client.send_message(to,"List is empty.")

                    if txt == "cmd list":
                            num=1
                            msgs=" ⌬ᴿᴳᴮᴼᵀˢ ᵛ.3.1⌬\n⌬ʟɪsᴛ ᴄᴏᴍᴍᴀɴᴅ⌬\n"
                            for a in self.commands["invite"]:
                                msgs+="\n%i. %s" % (num, a)
                                num=(num+1)
                            msgs+="\n\nTotal CMD List: %i" % len(self.commands["invite"])
                            if not silent:self.client.send_message(to, msgs)
                    if txt.startswith("list "):
                            ko = txt.split(" ")[1]
                            num=1
                            msgs=" ⌬ᴿᴳᴮᴼᵀˢ ᵛ.3.1⌬\n⌬ʟɪsᴛ ᴄᴏᴍᴍᴀɴᴅ⌬\n"
                            for a in self.commands["invite"][str(ko)]:
                                msgs+="\n%i. %s" % (num, self.client.get_contact(a).displayName)
                                num=(num+1)
                            msgs+="\n\nTotal List: %i" % len(self.commands["invite"][str(ko)])
                            if not silent:self.client.send_message(to, msgs)
                    if txt == ("cover list") and self.mode == 0:
                            num=1
                            msgs=" ⌬ᴿᴳᴮᴼᵀˢ ᵛ.3.1⌬\n⌬ʟɪsᴛ ʙᴀᴄᴋᴜᴘ⌬\n"
                            for a in self.status["backup"]:
                                if a != "all":
                                   nami = self.client.get_contact(a).displayName
                                else:nami = a
                                msgs+="\n%i. %s" % (num, nami)
                                num=(num+1)
                            msgs+="\n\nTotal List: %i" % len(self.status["backup"])
                            if not silent:self.client.send_message(to, msgs)
                if self.ranking(to,saya) < 5:
                  if txt == "responsename" or txt == "rname" or txt == "respon" or txt == sname + "rname":
                    if not silent:self.client.send_message(to,rname.rstrip())
                    print(rname)

                  if txt == "sname" or txt == "squad" or txt == "squadname":
                        if not silent:self.client.send_message(to,sname.rstrip())
                  if txt == 'clearban':
                     if self.status["blacklist"] != []:
                        jum = len(self.status["blacklist"])
                        self.status["blacklist"] = []
                        if not silent:self.client.send_message(to, "Cleared {} banlist".format(jum))
                        self.backupData()
                     else:
                        if not silent:self.client.send_message(to, "Empity")
                  for a in cmds:
                    if a.startswith(rname):txt = a.replace(a[:len(rname)],'')
                    elif a.startswith(sname):txt = a.replace(a[:len(sname)],'')
                    elif a.startswith("rgbots"):txt = a.replace(a[:len("rgbots")]+' ','')
                    elif cmds.index(a) != 0 and rname not in a and sname not in a:txt = a
                    if txt.startswith("rname "):
                        string = txt.split(" ")[1]
                        self.settings["cname"][msg.from_id] = string
                        self.backupData()
                        if not silent:self.client.send_message(to,"Responsename changed to " +self.settings["cname"][msg.from_id])
                    if txt.startswith("sname "):
                        string = txt.split(" ")[1]
                        self.settings["dname"][msg.from_id] = string
                        self.backupData()
                        if not silent:self.client.send_message(to,"Squad response changed to " +self.settings["dname"][msg.from_id])
                    if txt == 'reset rname':
                        if msg.from_id in self.settings['cname']:
                           del self.settings['cname'][msg.from_id]
                           self.backupData()
                        if not silent:self.client.send_message(to,"Responsename reseted to " +self.settings["rname"])
                    if txt == 'reset sname':
                        if msg.from_id in self.settings['dname']:
                           del self.settings['dname'][msg.from_id]
                           self.backupData()
                        if not silent:self.client.send_message(to,"Squad Response reseted to " +self.settings["sname"])
                    if txt == "hi" or txt == 'fetch':
                        a = self.client.sendMessage(to,"Hi !").createdTime
                        if not silent:self.client.sendMessage(to,"Fetchops: {}".format(a - op.createdTime))
                    if txt.startswith("addgowner"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Add Gowner \n',pg='ADDGO',pt=targets)
                      self.backupData()
                    if txt.startswith("delgowner"):
                      if to in self.status['gaccess']:
                            targets = []
                            if msg.mentionees:
                              self.mention(msg,targets)
                              self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del Gowner \n',pg='DELGO',pt=targets)
                            else:
                              data = txt.replace("delgowner","")
                              text = data.split(' ')
                              com = str(text[1])
                              selection = Archimed(com,range(1,len(self.status['gaccess'][to]['gowner'])+1))
                              k = len(self.status['gaccess'][to]['gowner'])//100
                              d = []
                              for c in selection.parse():
                                  d.append(self.status['gaccess'][to]['gowner'][int(c)-1])
                              for a in range(k+1):
                                  if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del Gowner \n',pg='DELGO',pt=d)
                                  else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del Gowner \n',pg='DELGO',pt=d)
                            self.backupData()
                    if txt.startswith("gcon"):
                      data = txt.replace("gcon","")
                      text = data.split(' ')
                      num = str(text[1])
                      gs = self.client.get_group(to) 
                      nama = [contact.mid for contact in gs.members]
                      num = str(text[1])
                      self.listcon(to,msg,num,self.status,nama)
                    if txt.startswith("addgadmin"):
                      targets = []
                      if msg.mentionees:
                        self.mention(msg,targets)
                        self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Add GAdmin \n',pg='ADDGA',pt=targets)
                      self.backupData()
                    if txt.startswith("delgadmin"):
                      if to in self.status['gaccess']:
                            targets = []
                            if msg.mentionees:
                              self.mention(msg,targets)
                              self.mentionmention(to=to,status=self.status,text='',dataMid=targets,pl=0,ps='    Del GAdmin \n',pg='DELGA',pt=targets)
                            else:
                              data = txt.replace("delgadmin","")
                              text = data.split(' ')
                              com = str(text[1])
                              selection = Archimed(com,range(1,len(self.status['gaccess'][to]['gadmin'])+1))
                              k = len(self.status['gaccess'][to]['gadmin'])//100
                              d = []
                              for c in selection.parse():
                                  d.append(self.status['gaccess'][to]['gadmin'][int(c)-1])
                              for a in range(k+1):
                                  if a == 0:self.mentionmention(to=to,status=self.status,text='',dataMid=d[:100],pl=-0,ps='    Del GAdmin \n',pg='DELGA',pt=d)
                                  else:self.mentionmention(to=to,status=self.status,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='    Del GAdmin \n',pg='DELGA',pt=d)
                            self.backupData()         
                    if txt.startswith('tagall'):
                      tt = txt.split(' ')
                      com = str(tt[1])
                      gs = self.client.get_group(to)
                      nama = [contact.mid for contact in gs.members]
                      no = 0
                      mids = []
                      selection = Archimed(com,range(1,len(nama)+1))
                      k = len(nama)//20
                      for a in range(k+1):
                        if a == 0:eto='     Tag Member \n'
                        else:eto='     Tag Member \n'
                        b=[]
                        text = ''
                        mids = []
                        no = 0
                        for i in selection.parse()[a*500 : (a+1)*500]:
                            mids.append(nama[i-1])
                        self.listdata(to,self.status,'Tag Member','tag',mids)

                    if txt == '/banlist' or txt == '/blacklist':
                        if self.status["blacklist"] == []:
                            if not silent:self.client.send_message(to,"Empty list")
                        else:
                            mc = ""
                            b = 0
                            for mi_d in self.status["blacklist"]:
                                b = b + 1
                                end = '\n'
                                try:
                                   mc += str(b) + " ❉⊱ " +self.client.get_contact(mi_d).displayName + "\n"
                                except Exception as e:self.status["blacklist"].remove(mi_d);print("del {}".format(mi_d))
                            self.backupData()
                            if not silent:self.client.send_message(to,"  Blacklist user:\n"+"\n"+mc)
                    if txt == "contact":
                        self.client.send_contact(msg.to_id, self.uid)

                    if txt == 'name':
                            s = self.client.profile
                            if not silent:self.client.send_message(to,s.displayName)

                    if txt == 'find staff':
                            stf = []
                            gs = self.client.get_group(to) 
                            nama = [contact.mid for contact in gs.members]
                            for tag in self.status["owner"]:
                                stf+=filter(lambda str: str == tag, nama)
                            for tag in self.status["admin"]:
                                stf+=filter(lambda str: str == tag, nama)
                            for tag in self.status["staff"]:
                                stf+=filter(lambda str: str == tag, nama)
                            for tag in self.creator:
                                stf+=filter(lambda str: str == tag, nama)
                            if to in self.status['gaccess']:
                                rooma = self.status['gaccess'][to]
                                for tag in rooma['gowner']:
                                    stf+=filter(lambda str: str == tag, nama) 
                                for tag in rooma['gadmin']:
                                    stf+=filter(lambda str: str == tag, nama) 
                            self.listdata(to,self.status,'Bot Staff','bot',stf)
                    if txt == 'find gstaff':
                            stf = []
                            gs = self.client.get_group(to) 
                            nama = [contact.mid for contact in gs.members]
                            if to in self.status['gaccess']:
                                rooma = self.status['gaccess'][to]
                                for tag in rooma['gowner']:
                                    stf+=filter(lambda str: str == tag, nama) 
                                for tag in rooma['gadmin']:
                                    stf+=filter(lambda str: str == tag, nama) 
                                self.listdata(to,self.status,'Bot Staff','bot',stf)
                            else:self.client.send_message(to,"Group staff is empty.")
                    if txt == 'my grade':
                        if self.pangkat(to,saya) == 0:
                            if not silent:self.sendtag(to, " Hail @! My Creator","OUP-Bot Protect", [saya])
                        elif self.pangkat(to,saya) == 1:
                            if not silent:self.sendtag(to, " Hail @! My Owner","OUP-Bot Protect", [saya])
                        elif self.pangkat(to,saya) == 2:
                            if not silent:self.sendtag(to, " Hail @! My Admin","OUP-Bot Protect", [saya])
                        elif self.pangkat(to,saya) == 4:
                            if not silent:self.sendtag(to, " Hail @! My Staff","OUP-Bot Protect", [saya])
                        else:
                            pass
                    if txt == 'speed':
                        start = time.time()
                      #  #self.client.send_message("u957b70fea5594dc505ced3fd44d23d19", '.'
                        try:self.client.send_message(self.client.profile.mid, '.')
                        except:pass
                        hasil = time.time()-start
                        if not silent:self.client.send_message(to, ' %.5f' % round(hasil,4)+ " ")
                        print(hasil)
                    if txt == "abort":
                        if not self.addcommand:
                            self.abort(to,silent)
                            self.backupData()
                        else:
                            self.addcmd = ""
                            self.addcommand = False
                            self.tempbots = []
                            self.backupData()
                            if not silent:self.client.send_message(to,"Command aborted.")
                    if txt == "commands":
                       rname = self.settings["rname"]
                       tst = "ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅs:\n_____________________________\n\n"
                       num=0
                       num1=0
                       num2=0
                       num3=0
                       num4=0
                       with open('helpi.json','r') as ini:
                            uh = json.load(ini)
                       mstr1 = uh["protect"]
                       mstr2 = uh["creator"]
                       mstr3 = uh["owner"]
                       mstr4 = uh["admin"]
                       mstr5 = uh["staff"]
                       num=(num+1)
                       num1=(num1+1)
                       num2=(num2+1)
                       num3=(num3+1)
                       num4=(num4+1)
                       if self.pangkat(to,msg.from_id) < 1:
                         tst += "\n\n       ⊰ ᴄʀᴇᴀᴛᴏʀ ᴄᴏᴍᴍᴀɴᴅs ⊱ "
                         for c in mstr2:
                           if num1 < 10:
                            tst += "\n %i.   %s %s "%(num1,rname,c)
                           else:
                            tst += "\n %i. %s %s "%(num1,rname,c)
                           num1=(num1+1)
                       tst += "\n\n        ⊰ ᴘʀᴏᴛᴇᴄᴛ ᴄᴏᴍᴍᴀɴᴅs ⊱ "
                       for c in mstr1:
                           if num < 10:
                            tst += "\n %i.   %s %s "%(num,rname,c)
                           else:
                            tst += "\n %i. %s %s "%(num,rname,c)
                           num=(num+1)
                       if self.pangkat(to,msg.from_id) < 2:
                         tst += "\n\n        ⊰ ᴏᴡɴᴇʀ ᴄᴏᴍᴍᴀɴᴅs ⊱ "
                         for c in mstr3:
                           if num2 < 10:
                            tst += "\n %i.   %s %s "%(num2,rname,c)
                           else:
                            tst += "\n %i. %s %s "%(num2,rname,c)
                           num2=(num2+1)
                       if self.pangkat(to,msg.from_id) < 3:
                         tst += "\n\n        ⊰ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs ⊱ "
                         for c in mstr4:
                           if num3 < 10:
                            tst += "\n %i.   %s %s "%(num3,rname,c)
                           else:
                            tst += "\n %i. %s %s "%(num3,rname,c)
                           num3=(num3+1)
                       if self.pangkat(to,msg.from_id) < 5:
                         tst += "\n\n       ⊰ sᴛᴀғғ ᴄᴏᴍᴍᴀɴᴅs ⊱ "
                         for c in mstr5:
                           if num4 < 10:
                            tst += "\n %i.   %s %s "%(num4,rname,c)
                           else:
                            tst += "\n %i. %s %s "%(num4,rname,c)
                           num4=(num4+1)
                       tst += "\n\n_____________________________\nᴿᴳᴮᴼᵀˢ ᵛ.3.1 "
                       if not silent:self.client.send_message(to,tst)
                    if txt == "help":
                        if rname in txt:ihik = rname
                        else:ihik = sname
                        md =  "   ⊰❉  ʜᴇʟᴘʟɪsᴛ  ❉⊱\n___________________\n\n"
                        md += "⊱ " + ihik + "commands " + "\n"
                        md += "⊱ " + ihik + "settings " + "\n"
                        md += "\n\n___________________\nᴿᴳᴮᴼᵀˢ ᵛ.3.1 "
                        if not silent:self.client.send_message(to,md)

                    #if txt == "detail":
                        #md =  "   ⊰❉ ʜᴇʟᴘ ᴅᴇᴛᴀɪʟ  ❉⊱\n___________________\n\n"
                        #md += "1.  C = send contact \n"
                        #md += "2.  R = <:>- " + "\n"
                        #md += "3.  @ = need tag " + "\n"
                        #md += "4.  all use rname or sname " + "\n"
                        #md += "\n\n___________________\nᴿᴳᴮᴼᵀˢ ᵛ.3.1 "
                        #if not silent:self.client.send_message(to,md)

                    if txt == 'set' or txt == "settings":
                        try: a = self.client.get_group(to).name
                        except: a = ''
                        md = "___________________________\n            ɢʀᴏᴜᴘ sᴇᴛᴛɪɴɢs \n____________________________\n ɢʀᴏᴜᴘɴᴀᴍᴇ: {}  \n\n  sɴᴀᴍᴇ:   ".format(a) + sname+ " \n  ʀɴᴀᴍᴇ:   "+ rname+ " \n\n"
                        if to in self.settings["cancel"]:
                            if self.settings["cancel"][to] == 1:md+="⊱ ᴅᴇɴʏɪɴᴠɪᴛᴇ: ᴏɴ\n"
                            elif self.settings["cancel"][to] == 2:md+="⊱ ᴅᴇɴʏɪɴᴠɪᴛᴇ: ᴏɴ𝟸\n"
                        else: md+= "⊱ ᴅᴇɴʏɪɴᴠɪᴛᴇ: ᴏғғ\n"
                        if self.settings["mute"]: md+="⊱ ᴍᴜᴛᴇ: ᴏɴ\n"
                        else: md+= "⊱ ᴍᴜᴛᴇ: ᴏғғ\n"
                        if to in self.settings["protect"]:
                            if self.settings["protect"][to] == 1:md+="⊱ ᴍᴀɪɴ ᴘʀᴏᴛᴇᴄᴛ: ᴏɴ\n"
                            elif self.settings["protect"][to] == 2:md+="⊱ ᴍᴀɪɴ ᴘʀᴏᴛᴇᴄᴛ: ᴏɴ𝟸\n"
                        else: md+= "⊱ ᴍᴀɪɴ ᴘʀᴏᴛᴇᴄᴛ: ᴏғғ\n"
                        if to in self.settings["linkprotect"]:
                            if self.settings["linkprotect"][to] == 1:md+="⊱ ʟɪɴᴋᴘʀᴏᴛᴇᴄᴛ: ᴏɴ\n"
                            elif self.settings["linkprotect"][to] == 2:md+="⊱ ʟɪɴᴋᴘʀᴏᴛᴇᴄᴛ: ᴏɴ𝟸\n"
                        else: md+= "⊱ ʟɪɴᴋᴘʀᴏᴛᴇᴄᴛ: ᴏғғ\n"
                        if self.settings["atjoin"]: md+="⊱ ᴀᴜᴛᴏᴊᴏɪɴ ᴜʀʟ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴜᴛᴏᴊᴏɪɴ ᴜʀʟ: ᴏғғ\n"
                        if to in self.settings["blj"]: md+="⊱ ᴘᴊᴏɪɴ: ᴏɴ\n"
                        else: md+= "⊱ ᴘᴊᴏɪɴ : ᴏғғ\n"
                        if to in self.settings["namelock"]: md+="⊱ ɴᴀᴍᴇʟᴏᴄᴋ: ᴏɴ\n"
                        else: md+= "⊱ ɴᴀᴍᴇʟᴏᴄᴋ: ᴏғғ\n"
                        if self.status["abl"]: md+="⊱ sᴄ ʙʟ: ᴏɴ\n"
                        else: md+= "⊱ sᴄ ʙʟ: ᴏғғ\n"
                        if self.status["aadmin"]: md+="⊱ ᴀᴅᴅ ᴀᴅᴍɪɴ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴅᴅ ᴀᴅᴍɪɴ : ᴏғғ\n"
                        if self.status["expel"]: md+="⊱ ᴇxᴘᴇʟ: ᴏɴ\n"
                        else: md+= "⊱ ᴇxᴘᴇʟ: ᴏғғ\n"
                        if self.status["astaff"]: md+="⊱ ᴀᴅᴅ sᴛᴀғғ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴅᴅ sᴛᴀғғ : ᴏғғ\n"
                        if self.status["abl"]: md+="❉⊱ ᴀᴅᴅ ʙʟ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴅᴅ ʙʟ : ᴏғғ\n"
                        if self.settings["purge"]: md+="⊱ ᴀᴜᴛᴏᴘᴜʀɢᴇ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴜᴛᴏᴘᴜʀɢᴇ : ᴏғғ\n"
                        #if self.settings["mode1"]: md+="❉⊱ Mode1     → ᴏɴ𝟸\n"
                        #else: md+="❉⊱ Mode2     → ᴏɴ𝟸\n"
                        if self.mode == 1:
                           if self.settings["war"]: md+="⊱ ᴡᴀʀ ᴍᴏᴅᴇ : ᴏɴ\n"
                           else: md+= "⊱ ᴡᴀʀ ᴍᴏᴅᴇ : ᴏғғ\n"
                        if self.mode == 0:
                          if self.settings["antimode"]: md+="⊱ sᴛᴀɴᴅʙʏ ᴍᴏᴅᴇ: ᴏɴ\n"
                          else: md+= "⊱ sᴛᴀɴᴅʙʏ ᴍᴏᴅᴇ : ᴏғғ\n"
                        if self.settings["lock"]: md+="⊱ ʟᴏᴄᴋ ᴍᴏᴅᴇ: ᴏɴ\n"
                        else: md+= "⊱ ʟᴏᴄᴋ ᴍᴏᴅᴇ : ᴏғғ\n"
                        if self.status["abot"]: md+="⊱ ᴀᴅᴅ ʙᴏᴛ: ᴏɴ\n"
                        else: md+= "⊱ ᴀᴅᴅ ʙᴏᴛ : ᴏғғ\n"
                        if self.status["repeat"]: md+="⊱ ʀᴇᴘᴇᴀᴛ: ᴏɴ\n"
                        else: md+= "⊱ ʀᴇᴘᴇᴀᴛ : ᴏғғ\n"
                        if self.bye == 1: md+="⊱ ʙʏᴇ ᴍᴇssᴀɢᴇ: ᴏɴ\n"
                        else: md+= "⊱ ʙʏᴇ ᴍᴇssᴀɢᴇ : ᴏғғ\n"
                        if self.settings['nuke']: md+="⊱ ɴᴜᴋᴇ ʙᴏᴛ: ᴏɴ\n"
                        else: md+= "⊱ ɴᴜᴋᴇ ʙᴏᴛ : ᴏғғ\n"
                        if not silent:self.client.send_message(msg.to_id,md + "\n____________________________\n  ᴿᴳᴮᴼᵀˢ ᵛ.3.1 ")

                    if txt.startswith('denyinvite ') or txt == 'denyinvite':
                        if txt.startswith('denyinvite '):
                            jenis = txt.replace('denyinvite ','')
                            if jenis == 'on' or jenis == '1':
                                self.settings["cancel"][to] = 1
                                if not silent:self.client.send_message(msg.to_id, "Deny invite enabled.")
                            elif jenis == 'max' or jenis == '2':
                                self.settings["cancel"][to] = 2
                                if not silent:self.client.send_message(msg.to_id, "Deny Invite Protection max enabled.")
                            elif jenis == 'off' or jenis == '0':
                                del self.settings["cancel"][to]
                                if not silent:self.client.send_message(msg.to_id, "Deny invite disabled.")
                            self.backupData()
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Use [off/0] [on/1] [max/2]")

                    if txt.startswith('namelock ') or txt == 'namelock':
                        if txt.startswith('namelock '):
                            jenis = txt.replace('namelock ','')
                            if jenis == 'on' or jenis == '1':
                                self.settings["namelock"][to] = {'on':1,'nama':self.client.get_group(to).name}
                                if not silent:self.client.send_message(msg.to_id, "Namelock enabled.")
                            elif jenis == 'off' or jenis == '0':
                                del self.settings["namelock"][to]
                                if not silent:self.client.send_message(msg.to_id, "Namelock disabled.")
                            self.backupData()
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Use [off/0] [on/1]")

                    if txt.startswith('protect ') or txt == 'rcon' or txt == 'rcof' or txt == 'protect':
                        if  txt.startswith('protect '):    
                            jenis = txt.replace('protect ','')
                            if jenis == 'on' or jenis == '1':
                                self.settings["protect"][to] = 1
                                if not silent:self.client.send_message(msg.to_id, "Protection enabled.")
                            elif jenis == 'max' or jenis == '2':
                                self.settings["protect"][to] = 2
                                if not silent:self.client.send_message(msg.to_id, "Protection max enabled.")
                            elif jenis == 'off' or jenis == '0':
                                self.settings["protect"][to] = 0
                                if not silent:self.client.send_message(msg.to_id, "Protection disabled.")
                        elif txt == 'rcon':
                                self.settings["protect"][to] = 1
                                if not silent:self.client.send_message(msg.to_id, "Ready </>")
                        elif txt == 'rcof':
                                self.settings["protect"][to] = 0
                                if not silent:self.client.send_message(msg.to_id, "Stay </>")
                        elif txt == 'protect':
                            if not silent:self.client.send_message(msg.to_id, "Use [off/0] [on/1] [max/2]")
                        self.backupData()

                    if txt.startswith('linkprotect ') or txt == 'linkprotect':
                        if txt.startswith('linkprotect '):    
                            jenis = txt.replace('linkprotect ','')
                            if jenis == 'on' or jenis == '1':
                                self.settings["linkprotect"][to] = 1
                                if not silent:self.client.send_message(msg.to_id, "Protection url protection enabled.")
                            elif jenis == 'max' or jenis == '2':
                                self.settings["linkprotect"][to] = 2
                                if not silent:self.client.send_message(msg.to_id, "Url Max Protection enabled.")
                            elif jenis == 'off' or jenis == '0':
                                del self.settings["protect"][to]
                                if not silent:self.client.send_message(msg.to_id, "Protection disabled.")
                            self.backupData()
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Use [off/0] [on/1] [max/2]")

                    if txt == 'pjoin on' or txt == 'blj on':
                        if to in self.settings["blj"] :
                            if not silent:self.client.send_message(msg.to_id, "Block join already enabled.")
                        else:
                            self.settings["blj"][to] = True
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Block join enabled.")

                    if txt == 'pjoin off':
                        if to in self.settings["blj"]:
                            del self.settings["blj"][to]
                            self.backupData()
                            if not silent:self.client.send_message(msg.to_id, "Allowing all joined members.")
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Block join already disabled.")

                    if txt.startswith('protection ') or txt == 'protection':
                        if txt.startswith('protection '):
                            jenis = txt.replace('protection ','')
                            if jenis == 'on' or jenis == '1':
                                self.settings["cancel"][to] = 1
                                self.settings["linkprotect"][to] = 1
                                self.settings["protect"][to] = 1
                               # self.settings["namelock"][to] = {'on':1,'nama':self.client.get_group(to).name}
                                if not silent:self.client.send_message(msg.to_id, "All protection enabled.")
                            elif jenis == 'max' or jenis == '2':
                                self.settings["cancel"][to] = 2
                                self.settings["linkprotect"][to] = 2
                                self.settings["protect"][to] = 2
                               # self.settings["namelock"][to] = {'on':1,'nama':self.client.get_group(to).name}
                                if not silent:self.client.send_message(msg.to_id, "Maximal protection enabled.")
                            elif jenis == 'none' or jenis == 'off':
                                if to in self.settings["cancel"]:
                                   del self.settings["cancel"][to]
                                if to in self.settings["linkprotect"]:
                                   del self.settings["linkprotect"][to]
                                self.settings["protect"][to] = 0
                                if to in self.settings["namelock"]:
                                   del self.settings["namelock"][to]
                                if to in self.settings["blj"]:
                                    del self.settings["blj"][to]
                                if not silent:self.client.send_message(msg.to_id, "All protection disabled.")
                            self.backupData()
                        else:
                            if not silent:self.client.send_message(msg.to_id, "Use [off/none] [on/1] [max/2]")

                    if txt == 'open link':
                            X = self.client.get_group(to)
                            X.preventedJoinByTicket = False
                            self.client.update_group(X)

                    if txt == 'close link':
                            X = self.client.get_group(to)
                            X.preventedJoinByTicket = True
                            self.client.update_group(X)

                    if txt == 'group link':
                            x = self.client.get_group(to)
                            if x.preventedJoinByTicket:
                                x.preventedJoinByTicket = False
                                self.client.update_group(x)
                            gurl = self.client.reissue_group_ticket(to)
                            if not silent:self.client.send_message(msg.to_id,"line://ti/g/" + gurl)

                    if txt == 'cancelall':
                            X = self.client.get_group(to)
                            if X.invitee is not None:
                                gInviMids = [contact.mid for contact in X.invitee]
                                for a in gInviMids:
                                   self.client.cancel_group_invitation(to, [a])
                                   time.sleep(1)

        if msg.content_type == 13:
                uid = msg.content_metadata["mid"]
                if self.pangkat(to,saya) < 1:
                    if self.status["aowner"]:
                      if uid in self.creator:
                            if not silent:self.sendtag(to,"User @! a creator.","Owner ADD",[uid])
                      else:
                        if uid not in self.status["owner"]:
                            self.status["owner"].append(uid)
                            try:
                                self.client.add_contact_by_mid(uid)
                            except:pass
                            if not silent:self.sendtag(to,"User @! added to owner.","Owner ADD",[uid])
                        else:
                            if not silent:self.sendtag(to,"User @! already on owner.","Owner ADD",[uid])
                        if uid in self.status["staff"]:
                                self.status["staff"].remove(uid)
                        if uid in self.status["bot"]:
                                self.status["bot"].remove(uid)
                        if uid in self.status["admin"]:
                                self.status["admin"].remove(uid)
                      if not self.status["repeat"]:
                          self.status["aowner"] = False
                    self.backupData()
                if self.pangkat(to,saya) < 2:
                    if self.addcommand:
                        if uid not in self.tempbots:
                            self.tempbots.append(uid)
                            self.client.add_contact_by_mid(uid)
                            if not silent:self.client.send_message(to,"User %s added to command %s"%(self.client.get_contact(uid).displayName,self.addcmd))
                        else:
                            if not silent:self.client.send_message(to,"%s already on list %s"%(self.client.get_contact(uid).displayName,self.addcmd))
                    elif self.addbackup:
                        if uid not in self.tempbots:
                            self.tempbots.append(uid)
                            self.client.add_contact_by_mid(uid)
                            if not silent:self.client.send_message(to,"User %s added to backup %s"%(self.client.get_contact(uid).displayName,self.client.get_contact(self.addcmd).displayName))
                        else:
                            if not silent:self.client.send_message(to,"%s already on backup list %s"%(self.client.get_contact(uid).displayName,self.client.get_contact(self.addcmd).displayName))
                    elif self.delbackup:
                        if uid in self.status["backup"]:
                            del self.status["backup"][uid]
                            self.backupData()
                            if not silent:self.client.send_message(to,"User %s deleted from backup list"%(self.client.get_contact(uid).displayName))
                        else:
                            if not silent:self.client.send_message(to,"%s not on backup user"%(self.client.get_contact(uid).displayName))
                    elif self.addbkp:
                        if uid not in self.status["backup"]["all"]:
                            self.status["backup"]["all"].append(uid)
                            self.client.add_contact_by_mid(uid)
                            self.backupData()
                            if not silent:self.client.send_message(to,"User %s added to all backup list"%(self.client.get_contact(uid).displayName))
                        else:
                            if not silent:self.client.send_message(to,"%s already on all backup list"%(self.client.get_contact(uid).displayName))

                    elif self.status["aadmin"]:
                      if uid in self.creator or uid in self.status["owner"]:
                            if not silent:self.sendtag(to,"User @! have higher grade.","Admin ADD",[uid])
                      else:
                        if uid not in self.status["admin"]:
                            self.status["admin"].append(uid)
                            try:
                                self.client.add_contact_by_mid(uid)
                            except:pass
                            if not silent:self.sendtag(to,"User @! added to admin list.","Admin ADD",[uid])
                        else:
                            if not silent:self.sendtag(to,"User @! already on admin list.","Admin ADD",[uid])
                        if uid in self.status["staff"]:
                                self.status["staff"].remove(uid)
                        if uid in self.status["bot"]:
                                self.status["bot"].remove(uid)
                      if not self.status["repeat"]:
                          self.status["aadmin"] = False
                    elif self.spam:
                        if uid not in self.sasaran:
                            self.sasaran.append(uid)
                            self.client.add_contact_by_mid(uid)
                            if not silent:self.client.send_message(to,"User %s added to spam list"%(self.client.get_contact(uid).displayName))
                        else:
                            if not silent:self.client.send_message(to,"%s already on spam list"%(self.client.get_contact(uid).displayName))
                    self.backupData()

                if self.pangkat(to,saya) < 3:
                    if self.status["astaff"]:
                      if uid in self.creator or uid in self.status["owner"]:
                            if not silent:self.sendtag(to,"User @! have higher grade.","Staff ADD",[uid])
                      else:
                        if uid not in self.status["staff"]:
                            self.status["staff"].append(uid)
                            try:
                                self.client.add_contact_by_mid(uid)
                            except:pass
                            if not silent:self.sendtag(to,"User @! added to staff.","Staff ADD",[uid])
                        else:
                            if not silent:self.sendtag(to,"User @! already on staff.","Staff ADD",[uid])
                        if uid in self.status["admin"]:
                                self.status["admin"].remove(uid)
                        if uid in self.status["bot"]:
                                self.status["bot"].remove(uid)
                      if not self.status["repeat"]:
                          self.status["astaff"] = False

                    if self.status["invite"]:
                            if uid in self.status["blacklist"]:
                                if not silent:self.sendtag(to,"Sorry, User @! in blacklist","Wong bejad",[uid])
                            else:
                                target = uid
                                try:
                                    self.client.add_contact_by_mid(target)
                                    self.client.invite_into_group(to,[target])
                                    self.status["invite"] = False
                                except:
                                    if not silent:self.client.send_message(to,"Limit plok")
                                    self.status["invite"] = False

                    if self.status["expel"]:
                        if self.pangkat(to,saya) < 3:
                            if uid in self.status["owner"]:
                              if self.pangkat(to,saya) < 1:
                                self.status["owner"].remove(uid)
                                if not silent:self.sendtag(to,"User @! expeled from owner.","Expel",[uid])
                            if uid in self.status["bot"]:
                                self.status["bot"].remove(uid)
                                if not silent:self.sendtag(to,"User @! expeled from bot.","Expel",[uid])
                            if uid in self.status["admin"]:
                              if self.pangkat(to,saya) < 2:
                                self.status["admin"].remove(uid)
                                if not silent:self.sendtag(to,"User @! expeled from admin.","Expel",[uid])
                            if uid in self.status["staff"]:
                                self.status["staff"].remove(uid)
                                if not silent:self.sendtag(to,"User @! expeled from staff.","Expel",[uid])
                            if uid in self.status["squad"]:
                              if self.pangkat(to,saya) < 2:
                                self.status["squad"].remove(uid)
                                if not silent:self.sendtag(to,"User @! expeled from bot.","Expel",[uid])
                        if not self.status["repeat"]:
                            self.status["expel"] = False

                    if self.status["abl"]:
                        if self.pangkat(to,saya) < 5:
                            if self.pangkat(to,uid) < 5:
                              if not silent:self.sendtag(to,"User @! already on user access.","Dulurmu",[uid])
                            else:
                                if uid not in self.status["blacklist"]:
                                   self.status["blacklist"].append(uid)
                                   if not silent:self.sendtag(to,"User @! added to blacklist.","Bejad",[uid])
                                else:self.sendtag(to,"User @! already on blacklist.","Bejad",[uid])
                        if not self.status["repeat"]:
                            self.status["abl"] = False

                    if self.status["abot"]:
                        if self.pangkat(to,saya) < 3:
                            if uid in self.status["admin"]:
                                self.status["admin"].remove(uid)
                            if uid in self.status["staff"]:
                                self.status["staff"].remove(uid)
                            if self.pangkat(to,uid) == 1:
                                if not silent:self.sendtag(to,"User @! already in owner.","Mbahmu",[uid])
                            if uid not in self.status["bot"]:
                                   self.status["bot"].append(uid)
                                   if not silent:self.sendtag(to,"User @! added to bot list.","Dulur",[uid])
                        if not self.status["repeat"]:
                            self.status["abl"] = False
                    self.backupData()
        if msg.content_type == 1:
            if self.pangkat(to,saya) < 2:
                    if self.status['picture']:
                        xpath = self.client.downloadObjectMsg(msg.id)
                        self.client.updateProfilePicture(xpath)
                        if not silent:self.client.send_message(to, "Profile picture successfully updated.")
                        self.client.deleteFile(xpath)
                        self.status['picture'] = False
                        self.backupData()
                    elif self.status['cvp']:
                        try:
                            path = self.client.downloadObjectMsg(msg.id)
                            self.status['gpic']['pic'] = path
                            self.backupData()
                            self.client.changecpvv(to,self.status)
                            if not silent:self.client.send_message(to, "Video profile successfully updated.")
                        except Exception as e:                   
                            if not silent:self.client.send_message(msg.to_id,"{}".format(e))
                    elif self.adc:
                           self.cover(msg)
                           self.adc = False
        if msg.content_type == 2:
                       if self.status['cvp']:
                        try:
                            path = self.client.downloadObjectMsg(msg.id)
                            self.status['gpic']['pic'] = ''
                            self.status['gpic']['vid'] = path
                            self.backupData()
                            self.client.changecpvv(to,self.status)
                            #self.client.deleteFile(path)
                        except Exception as e:
                            if not silent:self.client.send_message(to,str(e))

      except TalkException as talk_error:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif 'code=20' in e or 'code=7' in e or 'code=8' in e:
              self.backupData()
              sys.exit('FREEZING')
          elif 'code=7' in e or 'code=8' in e:
              self.backupData()
              sys.exit('AUTH FAILED')
          else:
            self.logError(e)
            print('error')
